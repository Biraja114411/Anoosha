export class TableRef {

    refKey1: string;
    refKey2: string;
    refKey3: string;
    refKey4: string;
    refCD: string;
    rcrdTypeCD: string;
    refVar1: string;
    refVar2: string;
    refVar3: string;
    refVar4: string;
    refVar5: string;
    refVar6: string;
    refVar7: string;
    refVar8: string;
    refVar9: string;
    refVar10: string;
    refVar11: string;
    refVar24: string;
    refVar25: string;
    
  }