import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { User } from '../login/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  user: User = new User();
   // BASE_PATH: 'http://localhost:8080'
   USER_NAME_SESSION_ATTRIBUTE_NAME = 'authenticatedUser'

   public username: String;
   public password: String;

  constructor(private http: HttpClient) { }

   /* authenticationService(username: String, password: String) {
    return this.http.get(`http://localhost:8080/finservice/api/v1/basicauth?username=`+username+'&password='+password,
      { headers: { authorization: this.createBasicAuthToken(username, password) } } ).pipe(map((res) => {
          console.log("hhh "+res);
          if(res)
          { 
              console.log("ggg ");
            this.username = username;
            this.password = password;
            this.registerSuccessfulLogin(username, password);
          }
          console.log(typeof res)

          return res;
      }));
  }  */

  authenticationService(username: String, password: String) {
    return this.http.get<User>(`http://localhost:8080/finservice/api/v1/advAuth?username=`+username+'&password='+password,
      { headers: { authorization: this.createBasicAuthToken(username, password) } } ).pipe(map((res) => {
          console.log("In auth hhh "+res);
          this.user= res;
          console.log(" In auth res "+this.user);
          var result = this.user.authStatus;
          console.log(" In auth res "+result);
          console.log(" In auth type "+typeof this.user.authStatus);
          if(this.user.authStatus)
          { 
              console.log("In auth ggg ");
            this.username = username;
            this.password = password;
            this.registerSuccessfulLogin(username, password,this.user.credFrm,this.user.custFrm);
          }
          console.log(typeof res)

          return res;
      }));
  } 

  createBasicAuthToken(username: String, password: String) {
    return 'Basic ' + window.btoa(username + ":" + password)
  }

  registerSuccessfulLogin(username, password,creditMenuSts,custMenuSts) {
    sessionStorage.setItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME, username)
    sessionStorage.setItem("creditMenuStatus", creditMenuSts)
    sessionStorage.setItem("custMenuStatus", custMenuSts)
  }

  logout() {
    sessionStorage.removeItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME);
    this.username = null;
    this.password = null;
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME)
    if (user === null) return false
    return true
  }

  getLoggedInUserName() {
    let user = sessionStorage.getItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME)
    if (user === null) return ''
    return user
  }
}
