import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { retry, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { CreditForm } from '../app/credit/creditform.model';
import { CustomerForm } from './customer/customerform.model';
import { OCRForm } from './customer/ocrform.model';
import { CountryForm } from './customer/countryform.model';
import { RegionForm } from './customer/regionForm.model';
import { TableRef } from './credit/tablerefform.model';

const HttpUploadOptions = {
  headers: new HttpHeaders({ 'Content-Type':'multipart/form-data' })
}
@Injectable({
  providedIn: 'root'
})

export class InvoiceserviceService {
  //private json_url = "http://localhost:4200/assets/json/invoice.json";
  //private json_url = "http://localhost:3000/api/v1/invoice/fetch/oi?inv_num=SHAN642741";
  private filnet_url = "http://localhost:8080/Acsf/downloadByinvoceId/?invoiceId=";
  private poc_url = "hhttp://localhost:9003/temppath/webrestcalc/1.0/Add?FIELD1=1&FIELD2=2";
  private creditform_url = "http://localhost:8080/finservice/saveCredit";
  private uploadFile_url = "http://localhost:8080/finservice/uploadFiletoDir";
  private getcreditform_url = "http://localhost:8080/finservice/getCreditForm?searchAcctNo=";
  private approverStatus_url = "http://localhost:8080/finservice/approverStatus?status=";
  private approverStatus_url_Level2 = "http://localhost:8080/finservice/approverFormLevel2?status=";
  private approverStatus_url_Level3 = "http://localhost:8080/finservice/approverFormLevel3?status=";
  private credit_form_get_head_office_credit_url = "http://localhost:8080/finservice/getHeadoffCreditLimit";


  private customerform_url = "http://localhost:8080/finservice/cma/saveCustomer";
  private custuploadFile_url = "http://localhost:8080/finservice/cma/uploadFiletoDir";
  private get_customer_form_url = "http://localhost:8080/finservice/cma/getCustomerForm?searchAcctNo=";
  private get_customer_form_ocr_url = "http://localhost:8080/finservice/cma/fetchOCRData";
  private get_customer_form_country_url = "http://localhost:8080/finservice/cma/fetchCountry";
  private get_customer_form_region_url = "http://localhost:8080/finservice/cma/fetchRegion?cntyCD=";
  private customer_form_approver_status_url = "http://localhost:8080/finservice/cma/approverStatus?status=";
  private customer_form_approver_form_level_2_url = "http://localhost:8080/finservice/cma/approverFormLevel2?status=";
  private getCompCodeApproverUrl = "http://localhost:8080/finservice/cma/getCompCodeApprover?ocr=";
  private fetchCompanyNameUrl = "http://localhost:8080/finservice/getCompanyName?companyName=";
  private fetchTableRefDataUrl = "http://localhost:8080/finservice/getTableRefData?accountNo=";

  constructor(private http: HttpClient) {
  }
  public getJson(invoiceId) {
    console.log(invoiceId)
    return this.http.get("http://localhost:3000/api/v1/invoice/fetch/oi?inv_num=" + invoiceId);
  }

  /*  public get(){  
     return this.http.get(this.json_url);  
   } */

  public searchFilenet(invoiceId) {
    console.log(invoiceId)
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('invoiceId', invoiceId);
    let body = urlSearchParams.toString();
    // let params = new HttpParams();
    // params = params.append('invoiceId', invoiceId);

    return this.http.post(this.filnet_url, invoiceId, { responseType: 'text' }).pipe(
      retry(1),
      catchError(this.handleError)
    )
      .subscribe(data => {
        console.log("Bye !!")
        alert(data);
        // console.log("Fetching"+data);
      });


  }

  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }

  public submitData(field1, field2) {
    console.log(field1, field2)
    let urlSearchParams = new URLSearchParams();
    //urlSearchParams.set();
    urlSearchParams.append('field1', field1);
    urlSearchParams.append('field2', field2);
    let body = urlSearchParams.toString();
    // let params = new HttpParams();
    // params = params.append('invoiceId', invoiceId);
    // Http Options
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/xml'
      })
    };

    return this.http.post(this.poc_url, body, httpOptions).pipe(
      retry(1),
      catchError(this.handleError)
    )
      .subscribe(data => {
        console.log("Bye !!")
        alert(data);
        // console.log("Fetching"+data);
      });


  }

  public saveForm(creditForm) {
    return this.http.post<CreditForm>(this.creditform_url, creditForm);
  }

  public uploadFiletoDir(uploadFile) {
    const formData = new FormData();
    formData.append('uploadFile', uploadFile);
    return this.http.post(this.uploadFile_url,formData);
  }

  public getForm(searchAcctNo,user) {
        return this.http.get<CreditForm>(this.getcreditform_url + searchAcctNo+'&user='+user);
  }

  public approverForm(creditForm,status,user) {
    return this.http.post<CreditForm>(this.approverStatus_url+status+'&user='+user, creditForm,user);
  }

  
  public approverFormLevel2(creditForm,status,user) {
    return this.http.post<CreditForm>(this.approverStatus_url_Level2+status+'&user='+user, creditForm,user);
  }

  public approverFormLevel3(creditForm,status,user) {
    return this.http.post<CreditForm>(this.approverStatus_url_Level3+status+'&user='+user, creditForm,user);
  }

  public fetchCompanyName(companyName) {
    return this.http.get<TableRef>(this.fetchCompanyNameUrl+companyName);
  }

  public getTableRefData(accountName,companyName) {
    return this.http.get<CreditForm>(this.fetchTableRefDataUrl+accountName+"&companyName="+companyName);
  }

  // Customer Form Methods

  public getCustomerForm(searchAcctNo, user) {
    return this.http.get<CustomerForm>(this.get_customer_form_url + searchAcctNo + '&user=' + user);
  }

  public saveCustomerForm(customerForm) {
    return this.http.post<CustomerForm>(this.customerform_url, customerForm);
  }

  public getRegion(value) {
    return this.http.get<RegionForm>(`${this.get_customer_form_region_url}`+value);
  }

  public getOCR(user) {
    return this.http.get<OCRForm>(`${this.get_customer_form_ocr_url}`);
  }

  public getCountry(user) {
    return this.http.get<CountryForm>(`${this.get_customer_form_country_url}`);
  }

  public approverCustomerForm(customerForm,status,user) {
    return this.http.post<CustomerForm>(this.customer_form_approver_status_url+status+'&user='+user,customerForm,user);
  }

  public approverCustomerFormLevel2(customerForm,status,user) {
    return this.http.post<CustomerForm>(this.customer_form_approver_form_level_2_url+status+'&user='+user,customerForm,user);
  }

  public getCompCodeApprover(value) {
    return this.http.get<CustomerForm>(`${this.getCompCodeApproverUrl}`+ value);
  }

  public custUploadFiletoDir(file) {
      let formdata: FormData = new FormData();
     formdata.append('file', file);
    return this.http.post(this.custuploadFile_url,formdata);
  }

 /*  public getHOCreditLimit(accNo) {
    return this.http.get<CreditForm>(`${this.credit_form_get_head_office_credit_url}?refCD="F_AR_CUSTOMER"&refKey1=${accNo}`);
  } */
}