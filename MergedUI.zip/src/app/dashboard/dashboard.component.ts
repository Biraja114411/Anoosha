import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  isCustMenuSts:boolean=false;
  isCreditMenuSts:boolean=false;
  user :string;
  constructor() { }

  ngOnInit() {

    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    this.user= user;
    var creditMenuStatus = sessionStorage.getItem('creditMenuStatus');
    console.log("creditMenuStatus " + creditMenuStatus);
    if(creditMenuStatus=='Y')
    {
      this.isCreditMenuSts=true;
    }
    var custMenuStatus = sessionStorage.getItem('custMenuStatus');
    if(custMenuStatus=='Y')
    {
      this.isCustMenuSts = true;
    }
    console.log("custMenuStatus " + custMenuStatus);
  }

}
