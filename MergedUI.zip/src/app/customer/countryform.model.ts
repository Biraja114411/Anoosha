
export class CountryForm {
    cntyCD: string;
    cntyName: string;
   
   
}