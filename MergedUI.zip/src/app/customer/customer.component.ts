import { Component, OnInit } from '@angular/core';
import { CustomerForm } from './customerform.model';
import { InvoiceserviceService } from '../invoiceservice.service';
import { Router } from '@angular/router';
import { OCRForm } from './ocrform.model';
import { CountryForm } from './countryform.model';
import { RegionForm } from './regionForm.model';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customerForm: CustomerForm = new CustomerForm();
  user: string = '';
  alerts: any = [];
  selectedFile: File;
  isShown: boolean = false;
  isShownSubmit: boolean = true;
  isAuth: boolean = false;
  isShownL2: boolean = false;
  isRejected: boolean = false;
  isApproverGrid: boolean = false;
  isApproved: boolean = false;
  firstAppStatus: string = "Pending With L1 Approver";
  secondAppStatus: string = "Pending With L1 Approver";
  globalCreditChk: boolean = false;
  isLevel3App: boolean = false;
  mandatoryFields: Array<string> = [];
  isCustMenuSts: boolean = false;
  isCreditMenuSts: boolean = false;
  ocrList:  OCRForm;
  countryList:  CountryForm;
  regionList:  RegionForm;

  constructor(private is: InvoiceserviceService, private router: Router) {
    this.mandatoryFields = ['customerName', 'addr1', 'addr2', 'city', 'state', 'zip', 'country', 'telephoneNo', 'contact', 'conTlephoneNo', 'conMobNo', 'conEmail', 'custAccGp', 'compCode', 'preMaterrec'];
  }

  ngOnInit() {
    const isLoggedin = sessionStorage.getItem('authenticatedUser');
    if (isLoggedin == 'false' || isLoggedin == null) {
      this.router.navigate(['/login']);
    }
    this.user = sessionStorage.getItem('authenticatedUser');
    const creditMenuStatus = sessionStorage.getItem('creditMenuStatus');
    if (creditMenuStatus == 'Y') {
      this.isCreditMenuSts = true;
    }
    const custMenuStatus = sessionStorage.getItem('custMenuStatus');
    if (custMenuStatus == 'Y') {
      this.isCustMenuSts = true;
    }
    this.prepopulateFields();
  }

  public addAlert(message, type) {
    this.alerts = [];
    this.alerts.push({
      message, type
    });
  }

  public prepopulateFields() {
    this.is.getCountry(this.user).subscribe(cData => {
     // console.log("ocrData"+ typeof cData)
      this.countryList = cData;
     // console.log("ocrData"+ this.countryList)
     // this.customerForm.country  = this.countryList.cntyName;
     // console.log("ocrData"+this.ocrList)
    });
     
    this.is.getOCR(this.user).subscribe(ocrData => {
      //console.log("ocrData"+ocrData)
     // console.log("ocrData"+ typeof ocrData)
      this.ocrList = ocrData;
     // console.log("ocrData"+ this.ocrList)
     // this.customerForm.ocr  = this.ocrList.ocr;
     // console.log("ocrData"+this.ocrList)
    });
  }

  public onCountrySelect(value)
  {
    
    console.log("value "+value)
    this.is.getRegion(value).subscribe(rData => {
      
      this.regionList = rData;
      console.log("regionList"+ this.regionList)
     // this.customerForm.region = this.regionList.region;
     // console.log("regionList"+this.ocrList)
    }); 
   
  }

  public onOCRSelect(value)
  {
    console.log("ocrData"+this.ocrList)
    console.log("value "+value)
    this.is.getCompCodeApprover(value).subscribe(rData => {
      this.customerForm.compCode = rData.compCode;
      this.customerForm.reqName = rData.reqName;
    }); 
   
  }

  public searchAcc(customerForm) {
    var user = sessionStorage.getItem('authenticatedUser');
    this.is.getCustomerForm(customerForm.searchAcctNo, user)
      .subscribe(data => {
        this.customerForm = data;
        if (this.customerForm.cmaFormSts == "Pending With L1 Approver" && this.customerForm.authStatus == "L1Access") {
          if (this.customerForm.userGroupId == this.customerForm.fstLevApprv) {
            this.isShown = true;
            this.isShownSubmit = false;
            this.isAuth = false;
          }
          else {
            this.isShownSubmit = false;
            this.isAuth = true;
          }
          this.isApproverGrid = true;

        }
        else if (this.customerForm.cmaFormSts == "Pending With L1 Approver" && this.customerForm.authStatus == "L1Reject") {
          this.isShown = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;

        }
        else if (this.customerForm.cmaFormSts == "Pending With L2 Approver" && this.customerForm.authStatus == "L2Access") {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Pending With L2 Approver";
          if (this.customerForm.userGroupId == this.customerForm.secLevApprv) {
            this.isShownL2 = true;
            this.isShownSubmit = false;
          }
          else {
            this.isAuth = true;
            this.isShownSubmit = false;
          }
          this.isApproverGrid = true;

        }
        else if (this.customerForm.cmaFormSts == 'Pending With L2 Approver' && this.customerForm.authStatus == 'L2Reject') {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Pending With L2 Approver";
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;

        }

        else if (this.customerForm.authStatus == 'Unauth' || this.customerForm.authStatus == null) {
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;

        }
        else if (this.customerForm.authStatus == 'Rejected' || this.customerForm.authStatus == null) {
          this.firstAppStatus = this.customerForm.cmaFormSts;
          this.secondAppStatus = this.customerForm.cmaFormSts;
          this.isShownSubmit = false;
          this.isRejected = true;
          this.isApproverGrid = true;

        }
        else if (this.customerForm.authStatus == null) {
          this.firstAppStatus = this.customerForm.cmaFormSts;
          this.secondAppStatus = this.customerForm.cmaFormSts;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;

        }
        else if (this.customerForm.cmaFormSts == 'Approved' && this.customerForm.authStatus == 'Approved') {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.isShownSubmit = false;
          this.isApproverGrid = true;
          this.isApproved = true;

        }
      });
  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0];
    console.log("file"+this.selectedFile)
    this.is.custUploadFiletoDir(this.selectedFile)
      .subscribe(data => {
        alert("File Uploaded successfully !!");
      });
  }

  saveForm() {
    this.customerForm.uploadFile = this.selectedFile;
    const mandatoryCheck = this.mandatoryFields.filter(f => !this.customerForm[f]);
    /* if (!!mandatoryCheck.length) {
      window.scrollTo(0, 0);
      this.addAlert("Please Enter Mandatory Fields !!", 'danger');
      return false;
    } */
    this.is.saveCustomerForm(this.customerForm)
      .subscribe(data => {
        this.customerForm = new CustomerForm();
        alert("Customer Form Saved successfully !!");
        window.location.reload();
      });
  }

  public approverCustomerForm(customerForm, status) {
    console.log(status + "Hey " + customerForm.accountNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    customerForm.user = user;
    this.is.approverCustomerForm(this.customerForm, status, user)
      .subscribe(data => {
        customerForm = new CustomerForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

  public approverFormLevel2(customerForm, status) {
    console.log(status + "Hey " + customerForm.accountNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    customerForm.user = user;
    this.is.approverCustomerFormLevel2(this.customerForm, status, user)
      .subscribe(data => {
        customerForm = new CustomerForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

}
