package com.apll.acsf.filenet.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Table(name = "OCR_COMP_APPR")
@Entity
@JsonIgnoreProperties
public class OCRCompModel {

	@Id
	@Column(name = "OCR")
	private String ocr;
	@Column(name = "COMP_CODE")
	private String compCode;
	@Column(name = "APPROVER")
	private String approver;
	@Column(name = "CREATED_BY")
	private char createdBy;
	@Column(name = "CREATED_DATE")
	private Date createdDate;

	public String getOcr() {
		return ocr;
	}

	public void setOcr(String ocr) {
		this.ocr = ocr;
	}

	public String getCompCode() {
		return compCode;
	}

	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public char getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(char createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "OCRCompModel [ocr=" + ocr + ", compCode=" + compCode + ", approver=" + approver + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + "]";
	}

}
