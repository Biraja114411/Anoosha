package com.apll.acsf.filenet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Table(name = "T005S_REGION")
@Entity
@JsonIgnoreProperties
public class RegionModel {

	@Id
	@Column(name = "COUNTRY")
	private String country;
	@Column(name = "REGION")
	private String region;
	@Column(name = "DESCRIPTION")
	private String description;

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "RegionModel [country=" + country + ", region=" + region + ", description=" + description + "]";
	}

}
