package com.apll.acsf.filenet.bean;

import java.sql.Date;

public class CustomerFormBean {

	private int custSeqNo;
	private String prevAcctNo;
	private String customerName;
	private char newCustSts;
	private String busRegNo;
	private String legalName;
	private String vatNo;
	private String addr1;
	private String addr2;
	private String city;
	private String state;
	private String zip;
	private String country;
	private String telephoneNo;
	private String faxNo;
	private String websiteUrl;
	private String region;
	private Date estDate;
	private char tempAddr1;
	private String tempAddr2;
	private String tempCity;
	private String tempState;
	private String tempZip;
	private String tempCountry;
	private String contact;
	private String bussDesignation;
	private String conTlephoneNo;
	private String conFax;
	private String conMobNo;
	private String conEmail;
	private String fcName;
	private String fcBisDesg;
	private String fcTelNo;
	private String fcFaxCode;
	private String fcMobNo;
	private String fcEmail;
	private String ackName;
	private Date ackSignature;
	private Date ackDate;
	private String custAccGp;
	private String ocr;
	private String compCode;
	private String prevMastRecno;
	private String reqName;
	private String reqDept;
	private String firstLevelaPpro;
	private String finApro;
	private String comments;
	private String fstLevApprv;
	private String secLevApprv;
	private String cmaFormSts;
	private String userGroupId;
	private String authStatus;

	public int getCustSeqNo() {
		return custSeqNo;
	}

	public void setCustSeqNo(int custSeqNo) {
		this.custSeqNo = custSeqNo;
	}

	public String getPrevAcctNo() {
		return prevAcctNo;
	}

	public void setPrevAcctNo(String prevAcctNo) {
		this.prevAcctNo = prevAcctNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public char getNewCustSts() {
		return newCustSts;
	}

	public void setNewCustSts(char newCustSts) {
		this.newCustSts = newCustSts;
	}

	public String getBusRegNo() {
		return busRegNo;
	}

	public void setBusRegNo(String busRegNo) {
		this.busRegNo = busRegNo;
	}

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	public String getVatNo() {
		return vatNo;
	}

	public void setVatNo(String vatNo) {
		this.vatNo = vatNo;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getTelephoneNo() {
		return telephoneNo;
	}

	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public Date getEstDate() {
		return estDate;
	}

	public void setEstDate(Date estDate) {
		this.estDate = estDate;
	}

	public char getTempAddr1() {
		return tempAddr1;
	}

	public void setTempAddr1(char tempAddr1) {
		this.tempAddr1 = tempAddr1;
	}

	public String getTempAddr2() {
		return tempAddr2;
	}

	public void setTempAddr2(String tempAddr2) {
		this.tempAddr2 = tempAddr2;
	}

	public String getTempCity() {
		return tempCity;
	}

	public void setTempCity(String tempCity) {
		this.tempCity = tempCity;
	}

	public String getTempState() {
		return tempState;
	}

	public void setTempState(String tempState) {
		this.tempState = tempState;
	}

	public String getTempZip() {
		return tempZip;
	}

	public void setTempZip(String tempZip) {
		this.tempZip = tempZip;
	}

	public String getTempCountry() {
		return tempCountry;
	}

	public void setTempCountry(String tempCountry) {
		this.tempCountry = tempCountry;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getBussDesignation() {
		return bussDesignation;
	}

	public void setBussDesignation(String bussDesignation) {
		this.bussDesignation = bussDesignation;
	}

	public String getConTlephoneNo() {
		return conTlephoneNo;
	}

	public void setConTlephoneNo(String conTlephoneNo) {
		this.conTlephoneNo = conTlephoneNo;
	}

	public String getConFax() {
		return conFax;
	}

	public void setConFax(String conFax) {
		this.conFax = conFax;
	}

	public String getConMobNo() {
		return conMobNo;
	}

	public void setConMobNo(String conMobNo) {
		this.conMobNo = conMobNo;
	}

	public String getConEmail() {
		return conEmail;
	}

	public void setConEmail(String conEmail) {
		this.conEmail = conEmail;
	}

	public String getFcName() {
		return fcName;
	}

	public void setFcName(String fcName) {
		this.fcName = fcName;
	}

	public String getFcBisDesg() {
		return fcBisDesg;
	}

	public void setFcBisDesg(String fcBisDesg) {
		this.fcBisDesg = fcBisDesg;
	}

	public String getFcTelNo() {
		return fcTelNo;
	}

	public void setFcTelNo(String fcTelNo) {
		this.fcTelNo = fcTelNo;
	}

	public String getFcFaxCode() {
		return fcFaxCode;
	}

	public void setFcFaxCode(String fcFaxCode) {
		this.fcFaxCode = fcFaxCode;
	}

	public String getFcMobNo() {
		return fcMobNo;
	}

	public void setFcMobNo(String fcMobNo) {
		this.fcMobNo = fcMobNo;
	}

	public String getFcEmail() {
		return fcEmail;
	}

	public void setFcEmail(String fcEmail) {
		this.fcEmail = fcEmail;
	}

	public String getAckName() {
		return ackName;
	}

	public void setAckName(String ackName) {
		this.ackName = ackName;
	}

	public Date getAckSignature() {
		return ackSignature;
	}

	public void setAckSignature(Date ackSignature) {
		this.ackSignature = ackSignature;
	}

	public Date getAckDate() {
		return ackDate;
	}

	public void setAckDate(Date ackDate) {
		this.ackDate = ackDate;
	}

	public String getCustAccGp() {
		return custAccGp;
	}

	public void setCustAccGp(String custAccGp) {
		this.custAccGp = custAccGp;
	}

	public String getOcr() {
		return ocr;
	}

	public void setOcr(String ocr) {
		this.ocr = ocr;
	}

	public String getCompCode() {
		return compCode;
	}

	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}

	public String getPrevMastRecno() {
		return prevMastRecno;
	}

	public void setPrevMastRecno(String prevMastRecno) {
		this.prevMastRecno = prevMastRecno;
	}

	public String getReqName() {
		return reqName;
	}

	public void setReqName(String reqName) {
		this.reqName = reqName;
	}

	public String getReqDept() {
		return reqDept;
	}

	public void setReqDept(String reqDept) {
		this.reqDept = reqDept;
	}

	public String getFirstLevelaPpro() {
		return firstLevelaPpro;
	}

	public void setFirstLevelaPpro(String firstLevelaPpro) {
		this.firstLevelaPpro = firstLevelaPpro;
	}

	public String getFinApro() {
		return finApro;
	}

	public void setFinApro(String finApro) {
		this.finApro = finApro;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getFstLevApprv() {
		return fstLevApprv;
	}

	public void setFstLevApprv(String fstLevApprv) {
		this.fstLevApprv = fstLevApprv;
	}

	public String getSecLevApprv() {
		return secLevApprv;
	}

	public void setSecLevApprv(String secLevApprv) {
		this.secLevApprv = secLevApprv;
	}

	public String getCmaFormSts() {
		return cmaFormSts;
	}

	public void setCmaFormSts(String cmaFormSts) {
		this.cmaFormSts = cmaFormSts;
	}

	public String getUserGroupId() {
		return userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}

	public String getAuthStatus() {
		return authStatus;
	}

	public void setAuthStatus(String authStatus) {
		this.authStatus = authStatus;
	}

	@Override
	public String toString() {
		return "CustomerFormBean [custSeqNo=" + custSeqNo + ", prevAcctNo=" + prevAcctNo + ", customerName="
				+ customerName + ", newCustSts=" + newCustSts + ", busRegNo=" + busRegNo + ", legalName=" + legalName
				+ ", vatNo=" + vatNo + ", addr1=" + addr1 + ", addr2=" + addr2 + ", city=" + city + ", state=" + state
				+ ", zip=" + zip + ", country=" + country + ", telephoneNo=" + telephoneNo + ", faxNo=" + faxNo
				+ ", websiteUrl=" + websiteUrl + ", region=" + region + ", estDate=" + estDate + ", tempAddr1="
				+ tempAddr1 + ", tempAddr2=" + tempAddr2 + ", tempCity=" + tempCity + ", tempState=" + tempState
				+ ", tempZip=" + tempZip + ", tempCountry=" + tempCountry + ", contact=" + contact
				+ ", bussDesignation=" + bussDesignation + ", conTlephoneNo=" + conTlephoneNo + ", conFax=" + conFax
				+ ", conMobNo=" + conMobNo + ", conEmail=" + conEmail + ", fcName=" + fcName + ", fcBisDesg="
				+ fcBisDesg + ", fcTelNo=" + fcTelNo + ", fcFaxCode=" + fcFaxCode + ", fcMobNo=" + fcMobNo
				+ ", fcEmail=" + fcEmail + ", ackName=" + ackName + ", ackSignature=" + ackSignature + ", ackDate="
				+ ackDate + ", custAccGp=" + custAccGp + ", ocr=" + ocr + ", compCode=" + compCode + ", prevMastRecno="
				+ prevMastRecno + ", reqName=" + reqName + ", reqDept=" + reqDept + ", firstLevelaPpro="
				+ firstLevelaPpro + ", finApro=" + finApro + ", comments=" + comments + ", fstLevApprv=" + fstLevApprv
				+ ", secLevApprv=" + secLevApprv + ", cmaFormSts=" + cmaFormSts + ", userGroupId=" + userGroupId
				+ ", authStatus=" + authStatus + "]";
	}

}
