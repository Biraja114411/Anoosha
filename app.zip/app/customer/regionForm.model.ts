
export class RegionForm {
    country: string;
    region: string;
    description: string;
    
}