import { Component, OnInit } from '@angular/core';
import { CreditForm } from '../credit/creditform.model';
import { InvoiceserviceService } from '../invoiceservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-credit',
  templateUrl: './credit.component.html',
  styleUrls: ['./credit.component.css']
})
export class CreditComponent implements OnInit {

  creditform: CreditForm = new CreditForm();
  alerts: any = [];
  selectedFile: File;
  creditforms: CreditForm;
  isShown: boolean = false;
  isShownSubmit: boolean = true;
  isAuth: boolean = false;
  isShownL2: boolean = false;
  isRejected: boolean = false;
  isApproverGrid: boolean = false;
  isShownL3: boolean = false;
  isApproved: boolean = false;
  firstAppStatus: string = "Pending With L1 Approver";
  secondAppStatus: string = "Pending With L1 Approver";
  thirdAppStatus: string = "Pending With L1 Approver";
  globalCreditChk: boolean = false;
  isLevel3App: boolean = false;
  isMaster: boolean = false;
  
  constructor(private is: InvoiceserviceService, private router: Router) { }

  ngOnInit() {
    var isLoggedin = sessionStorage.getItem('authenticatedUser');
    if (isLoggedin == 'false' || isLoggedin == null) {
      // this.router.navigate(['/login']);
    }
    var user = sessionStorage.getItem('authenticatedUser');
  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0]
    this.is.uploadFiletoDir(this.selectedFile)
      .subscribe(data => {
        alert("File Uploaded successfully !!");
      });
  }

  public addAlert(message, type) {
    this.alerts = [];
    this.alerts.push({
      message, type
    });
  }

  public toggleVisibility(e) {
    this.globalCreditChk = e.target.checked;
  }

  public masterChildSwitch(e) {
    this.isMaster = e.target.value === 'master';
    this.creditform.globalCreditLimit = !!e.target.value;
    this.globalCreditChk = !!e.target.value;
    if (e && e.target.value === 'master') {
      this.populateHeadOffice();
      this.populateCreditLimit();
    }
  }

  public populateHeadOffice() {
    //api to fetch headoffice will be called here and the response will be added to the textbox
  }

  public populateCreditLimit() {
    //api to fetch credit limit will be called here and the response will be added to the textbox
  }

  public saveForm() {
    this.creditform.uploadFile = this.selectedFile;
    if (this.creditform.accountNo == null || this.creditform.companyName == null || this.creditform.country == null || this.creditform.companyCode == null ||
      this.creditform.globalAccCheck == null || this.creditform.preferredCurrencyForPayment == null || this.creditform.creditOwnwerAccountNo == null || this.creditform.creditReqAmount == null ||
      this.creditform.creditRecAmount == null || this.creditform.justificationRequest == null || this.creditform.desProposedServices == null ||
      this.creditform.totAccountNo == null || this.creditform.totReqAmount == null || this.creditform.totRecAmount == null || this.creditform.litigationFlag == null) {
      window.scrollTo(0, 0);
      this.addAlert("Please Enter Mandatory Fields !!", 'danger');
      return false;
    }
    if (this.globalCreditChk == true && this.creditform.headOffice == null) {
      window.scrollTo(0, 0);
      this.addAlert("If Global Credit Limit is checked ,It is Mandatory to enter Enter Office Field !!", 'danger');
      return false;
    }
    this.is.saveForm(this.creditform)
      .subscribe(data => {
        this.creditform = new CreditForm();
        alert("Credit Form Saved successfully !!");
        window.location.reload();
      });
  }

  public searchAcc(creditform) {
    var user = sessionStorage.getItem('authenticatedUser');
    this.is.getForm(creditform.searchAcctNo, user)
      .subscribe(data => {
        this.creditform = data;
        if (this.creditform.creditformStatus == "Pending With L1 Approver" && this.creditform.authStatus == "L1Access") {
          if (this.creditform.userGroupId == this.creditform.firstLevelApp) {
            this.isShown = true;
            this.isShownSubmit = false;
            this.isAuth = false;
          }
          else {
            this.isShownSubmit = false;
            this.isAuth = true;
          }
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == "Pending With L1 Approver" && this.creditform.authStatus == "L1Reject") {
          this.isShown = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == "Pending With L2 Approver" && this.creditform.authStatus == "L2Access") {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Pending With L2 Approver";
          this.thirdAppStatus = "Pending With L2 Approver";
          if (this.creditform.userGroupId == this.creditform.secLevelApp) {
            this.isShownL2 = true;
            this.isShownSubmit = false;

          }
          else {
            this.isAuth = true;
            this.isShownSubmit = false;
          }
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == 'Pending With L2 Approver' && this.creditform.authStatus == 'L2Reject') {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Pending With L2 Approver";
          this.thirdAppStatus = "Pending With L2 Approver";
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == "Pending With L3 Approver" && this.creditform.authStatus == "L3Access") {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.thirdAppStatus = "Pending With L3 Approver";
          if (this.creditform.userGroupId == this.creditform.thirdLevelApp) {
            this.isShownL3 = true;
            this.isShownSubmit = false;

          }
          else {
            this.isAuth = true;
            this.isShownSubmit = false;
          }
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == 'Pending With L3 Approver' && this.creditform.authStatus == 'L3Reject') {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.thirdAppStatus = "Pending With L3 Approver";
          this.isShownL3 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.authStatus == 'Unauth' || this.creditform.authStatus == null) {
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.authStatus == 'Rejected' || this.creditform.authStatus == null) {
          this.firstAppStatus = this.creditform.creditformStatus;
          this.secondAppStatus = this.creditform.creditformStatus;
          this.thirdAppStatus = this.creditform.creditformStatus;
          this.isShownSubmit = false;
          this.isRejected = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.authStatus == null) {
          this.firstAppStatus = this.creditform.creditformStatus;
          this.secondAppStatus = this.creditform.creditformStatus;
          this.thirdAppStatus = this.creditform.creditformStatus;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == 'Approved' && this.creditform.authStatus == 'Approved') {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.thirdAppStatus = "Approved";
          this.isShownSubmit = false;
          this.isApproverGrid = true;
          this.isApproved = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
      });
  }

  public approverForm(creditform, status) {
    var user = sessionStorage.getItem('authenticatedUser');
    creditform.user = user;
    this.is.approverForm(this.creditform, status, user)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

  public approverFormLevel2(creditform, status) {
    var user = sessionStorage.getItem('authenticatedUser');
    creditform.user = user;
    this.is.approverFormLevel2(this.creditform, status, user)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

  public approverFormLevel3(creditform, status) {
    var user = sessionStorage.getItem('authenticatedUser');
    creditform.user = user;
    this.is.approverFormLevel3(this.creditform, status, user)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

}
