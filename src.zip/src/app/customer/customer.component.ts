import { Component, OnInit } from '@angular/core';
import { CustomerForm } from './customerform.model';
import { InvoiceserviceService } from '../invoiceservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customerForm: CustomerForm = new CustomerForm();
  user: string = '';
  alerts: any = [];
  selectedFile: File;
  isShown: boolean = false;
  isShownSubmit: boolean = true;
  isAuth: boolean = false;
  isShownL2: boolean = false;
  isRejected: boolean = false;
  isApproverGrid: boolean = false;
  isShownL3: boolean = false;
  isApproved: boolean = false;
  firstAppStatus: string = "Pending With L1 Approver";
  secondAppStatus: string = "Pending With L1 Approver";
  thirdAppStatus: string = "Pending With L1 Approver";
  globalCreditChk: boolean = false;
  isLevel3App: boolean = false;
  mandatoryFields: Array<string> = [];

  constructor(private is: InvoiceserviceService, private router: Router) { 
    this.mandatoryFields = ['customerName', 'addr1', 'addr2', 'city', 'state', 'zip', 'country', 'telephoneNo', 'contact', 'conTlephoneNo', 'conMobNo', 'conEmail', 'custAccGp', 'compCode', 'preMaterrec'];
  }

  ngOnInit() {
    var isLoggedin = sessionStorage.getItem('authenticatedUser');
    if (isLoggedin == 'false' || isLoggedin == null) {
      // this.router.navigate(['/login']);
    }
    this.user = sessionStorage.getItem('authenticatedUser');
    this.prepopulateFields();
  }

  public addAlert(message, type) {
    this.alerts = [];
    this.alerts.push({
      message, type
    });
  }

  public prepopulateFields() {
    this.is.getCountry(this.user).subscribe(cData=>{
      //populate country field values here
    });
    this.is.getRegion(this.user).subscribe(rData=>{
      //populate region field values here
    });
    this.is.getOCR(this.user).subscribe(ocrData=>{
      //populate OCR field values here
    });
  }

  public searchAcc(customerForm) {
    var user = sessionStorage.getItem('authenticatedUser');
    this.is.getCustomerForm(customerForm.searchAcctNo, user)
      .subscribe(data => {
        this.customerForm = data;
        if (this.customerForm.newCustSts == "Pending With L1 Approver" && this.customerForm.authStatus == "L1Access") {
          if (this.customerForm.userGroupId == this.customerForm.fstLevApprv) {
            this.isShown = true;
            this.isShownSubmit = false;
            this.isAuth = false;
          }
          else {
            this.isShownSubmit = false;
            this.isAuth = true;
          }
          this.isApproverGrid = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
        else if (this.customerForm.newCustSts == "Pending With L1 Approver" && this.customerForm.authStatus == "L1Reject") {
          this.isShown = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
        else if (this.customerForm.newCustSts == "Pending With L2 Approver" && this.customerForm.authStatus == "L2Access") {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Pending With L2 Approver";
          this.thirdAppStatus = "Pending With L2 Approver";
          if (this.customerForm.userGroupId == this.customerForm.secLevApprv) {
            this.isShownL2 = true;
            this.isShownSubmit = false;
          }
          else {
            this.isAuth = true;
            this.isShownSubmit = false;
          }
          this.isApproverGrid = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
        else if (this.customerForm.newCustSts == 'Pending With L2 Approver' && this.customerForm.authStatus == 'L2Reject') {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Pending With L2 Approver";
          this.thirdAppStatus = "Pending With L2 Approver";
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
        else if (this.customerForm.newCustSts == "Pending With L3 Approver" && this.customerForm.authStatus == "L3Access") {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.thirdAppStatus = "Pending With L3 Approver";
          // if (this.customerForm.userGroupId == this.customerForm.thirdLevelApp) {
          //   this.isShownL3 = true;
          //   this.isShownSubmit = false;

          // }
          // else {
          //   this.isAuth = true;
          //   this.isShownSubmit = false;
          // }
          this.isApproverGrid = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
        else if (this.customerForm.newCustSts == 'Pending With L3 Approver' && this.customerForm.authStatus == 'L3Reject') {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.thirdAppStatus = "Pending With L3 Approver";
          this.isShownL3 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
        else if (this.customerForm.authStatus == 'Unauth' || this.customerForm.authStatus == null) {
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
        else if (this.customerForm.authStatus == 'Rejected' || this.customerForm.authStatus == null) {
          this.firstAppStatus = this.customerForm.newCustSts;
          this.secondAppStatus = this.customerForm.newCustSts;
          this.thirdAppStatus = this.customerForm.newCustSts;
          this.isShownSubmit = false;
          this.isRejected = true;
          this.isApproverGrid = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
        else if (this.customerForm.authStatus == null) {
          this.firstAppStatus = this.customerForm.newCustSts;
          this.secondAppStatus = this.customerForm.newCustSts;
          this.thirdAppStatus = this.customerForm.newCustSts;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
        else if (this.customerForm.newCustSts == 'Approved' && this.customerForm.authStatus == 'Approved') {
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.thirdAppStatus = "Approved";
          this.isShownSubmit = false;
          this.isApproverGrid = true;
          this.isApproved = true;
          // if(this.customerForm.recDaysIFS>=45 || this.customerForm.recDaysCNS>=45 || this.customerForm.recDaysDNS>=45 || this.customerForm.recDaysCLS>=45 || this.customerForm.recDaysIMS>=45 ||
          //   this.customerForm.recDaysTMS>=45 || this.customerForm.recDaysAUT>=45 || this.customerForm.recDaysVAS>=45 || this.customerForm.recDaysINR>=45
          // || this.customerForm.recDaysOthers>=45 || this.customerForm.recDaysValidValues>=45)
          // {
          //   this.isLevel3App =true;
          // }
        }
      });
  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0];
    const formData = new FormData();
    formData.append('uploadedFile', this.selectedFile);
    this.is.uploadFiletoDir(formData)
      .subscribe(data => {
        alert("File Uploaded successfully !!");
      });
  }

  saveForm() {
    this.customerForm.uploadFile = this.selectedFile;
    const mandatoryCheck = this.mandatoryFields.filter(f=>!this.customerForm[f]);
    if(!!mandatoryCheck.length) {
      window.scrollTo(0, 0);
      this.addAlert("Please Enter Mandatory Fields !!", 'danger');
      return false;
    }
    this.is.saveCustomerForm(this.customerForm)
      .subscribe(data => {
        this.customerForm = new CustomerForm();
        alert("Customer Form Saved successfully !!");
        window.location.reload();
      });
  }

}
