package com.apll.acsf.filenet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Table(name = "T005_COUNTRY")
@Entity
@JsonIgnoreProperties
public class Country {

	@Id
	@Column(name = "CNTY_CD")
	private String cntyCD;
	@Column(name = "CNTY_NAME")
	private String cntyName;

	public String getCntyCD() {
		return cntyCD;
	}

	public void setCntyCD(String cntyCD) {
		this.cntyCD = cntyCD;
	}

	public String getCntyName() {
		return cntyName;
	}

	public void setCntyName(String cntyName) {
		this.cntyName = cntyName;
	}

	@Override
	public String toString() {
		return "Country [cntyCD=" + cntyCD + ", cntyName=" + cntyName + "]";
	}

}
