package com.apll.acsf.filenet.bean;

public class UserBean {

	private String username;
	private String password;
	private String authStatus="false";
	private String firstLeveApprover;
	private String secondLevelApprover;
	private String thirdLevelApprover;
	private String groupId;
	private String custFrm;
	private String credFrm;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAuthStatus() {
		return authStatus;
	}

	public void setAuthStatus(String authStatus) {
		this.authStatus = authStatus;
	}

	public String getFirstLeveApprover() {
		return firstLeveApprover;
	}

	public void setFirstLeveApprover(String firstLeveApprover) {
		this.firstLeveApprover = firstLeveApprover;
	}

	public String getSecondLevelApprover() {
		return secondLevelApprover;
	}

	public void setSecondLevelApprover(String secondLevelApprover) {
		this.secondLevelApprover = secondLevelApprover;
	}

	public String getThirdLevelApprover() {
		return thirdLevelApprover;
	}

	public void setThirdLevelApprover(String thirdLevelApprover) {
		this.thirdLevelApprover = thirdLevelApprover;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getCredFrm() {
		return credFrm;
	}

	public void setCredFrm(String credFrm) {
		this.credFrm = credFrm;
	}

	public String getCustFrm() {
		return custFrm;
	}

	public void setCustFrm(String custFrm) {
		this.custFrm = custFrm;
	}

	@Override
	public String toString() {
		return "UserBean [username=" + username + ", password=" + password + ", authStatus=" + authStatus
				+ ", firstLeveApprover=" + firstLeveApprover + ", secondLevelApprover=" + secondLevelApprover
				+ ", thirdLevelApprover=" + thirdLevelApprover + ", groupId=" + groupId + ", custFrm=" + custFrm
				+ ", credFrm=" + credFrm + "]";
	}

	

}
