const express = require('express');
const exphbs = require('express-handlebars');
var path = require('path');
const app = express();

app.engine('hbs', exphbs());
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(__dirname + '/public'));
const port = 3001;

app.get('/', function (req, res) {
    res.render('index')
})

app.use(function (req, res, next) {
    next();
})

app.listen(port, () =>
    console.log('app running on port ' + port))