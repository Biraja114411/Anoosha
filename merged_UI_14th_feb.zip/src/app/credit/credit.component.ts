import { Component, OnInit } from '@angular/core';
import { CreditForm } from '../credit/creditform.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { InvoiceserviceService } from '../invoiceservice.service';
import { HttpResponse, HttpEventType } from '@angular/common/http';
import { Observable, Subject, of, concat } from "rxjs";
import { Router } from '../../../node_modules/@angular/router';
import { User } from '../login/user.model';
import { distinctUntilChanged, tap, switchMap, catchError } from 'rxjs/operators';
import { TableRef } from './tablerefform.model';


@Component({
  selector: 'app-credit',
  templateUrl: './credit.component.html',
  styleUrls: ['./credit.component.css']
})
export class CreditComponent implements OnInit {
  creditform: CreditForm = new CreditForm();
  display: any = {
    selectedCompanyName: [],
    suggestedCompanyList: new Observable<TableRef[]>(),
    companyNameLoading: false,
    companyTypeAhead: new Subject<string>()
  };
  alerts: any = [];
  selectedFile: File;
  creditforms: CreditForm;
  isShown: boolean = false;
  isShownSubmit: boolean = true;
  isAuth: boolean = false;
  isShownL2: boolean = false;
  isRejected: boolean = false;
  isApproverGrid: boolean = false;
  isShownL3: boolean = false;
  isApproved: boolean = false;
  firstAppStatus: string = "Pending With L1 Approver";
  secondAppStatus: string = "Pending With L1 Approver";
  thirdAppStatus: string = "Pending With L1 Approver";
  globalCreditChk: boolean = false;
  isLevel3App: boolean = false;
  isMaster: boolean = false;
  isCustMenuSts: boolean = false;
  isCreditMenuSts: boolean = false;
  user: string = '';
  constructor(private is: InvoiceserviceService, private router: Router) { }

  ngOnInit() {
    var isLoggedin = sessionStorage.getItem('authenticatedUser');
    if (isLoggedin == 'false' || isLoggedin == null) {
      this.router.navigate(['/login']);
    }

    this.user = sessionStorage.getItem('authenticatedUser');
    var creditMenuStatus = sessionStorage.getItem('creditMenuStatus');
    if (creditMenuStatus == 'Y') {
      this.isCreditMenuSts = true;
    }
    var custMenuStatus = sessionStorage.getItem('custMenuStatus');
    if (custMenuStatus == 'Y') {
      this.isCustMenuSts = true;
    }
    this.fetchCompanyName();
  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0]
    console.log("Hefg " + this.selectedFile)
    this.is.uploadFiletoDir(this.selectedFile)
      .subscribe(data => {
        alert("File Uploaded successfully !!");
      });
  }

  public addAlert(message, type) {
    this.alerts = [];
    this.alerts.push({
      message, type
    });
  }

  public toggleVisibility(e) {
    this.globalCreditChk = e.target.checked;
    if (e && e.target.value === 'false') {
      this.creditform.globalCreditLimit = null;
    }
  }

  public masterChildSwitch(e) {
    this.isMaster = e.target.value === 'master';
    this.creditform.globalCreditLimit = !!e.target.value;
    this.globalCreditChk = !!e.target.value;
    if (e && e.target.value === 'master') {
      //this.populateHeadOfficeCreditLimit(creditform);
    }

    if (e && e.target.value === 'child') {
      this.creditform.globalCreditLimit = null;
    }
  }

  private fetchCompanyName() {
    this.display.suggestedCompanyList = concat(
      of([]), // default items
      this.display.companyTypeAhead.pipe(
        distinctUntilChanged(),
        tap(() => this.display.companyNameLoading = true),
        switchMap(term => this.is.fetchCompanyName(term).pipe(
          catchError(() => of([])), // empty list on error
          tap((s) => { this.display.companyNameLoading = false; })
        ))
      )
    );
  }

  /**
   * onCompanySelect
   */
  public onCompanySelect(e) {
    if (!!e.refKey1) {
      this.creditform.companyName = e.refKey1;
      this.is.fetchCompanyName(e.refKey1).subscribe((data) => {
        //please add proper key to populate below form fields
        this.creditform.accountNo = data.refVar1;
        this.creditform.companyAddress = data.refVar1;
        this.creditform.companyCode = data.refVar1;
      });
    }
  }

  /* public populateHeadOfficeCreditLimit(creditform) {
    console.log("test "+creditform)
    this.is.getHOCreditLimit(creditform.accountNo).subscribe(data=> {
      this.creditform.headOffice = data.headOffice;
      this.creditform.creditLimitMastCust = data.creditLimitMastCust;
    })
  } */
  public saveForm() {
    this.creditform.uploadFile = this.selectedFile;
    if (this.creditform.accountNo == null || this.creditform.companyName == null || this.creditform.country == null || this.creditform.companyCode == null ||
      this.creditform.globalAccCheck == null || this.creditform.preferredCurrencyForPayment == null || this.creditform.creditOwnwerAccountNo == null || this.creditform.creditReqAmount == null ||
      this.creditform.creditRecAmount == null || this.creditform.justificationRequest == null || this.creditform.desProposedServices == null ||
      this.creditform.totAccountNo == null || this.creditform.totReqAmount == null || this.creditform.totRecAmount == null || this.creditform.litigationFlag == null) {
      window.scrollTo(0, 0);
      this.addAlert("Please Enter Mandatory Fields !!", 'danger');
      return false;
    }
    if (this.globalCreditChk == true && this.creditform.headOffice == null) {
      window.scrollTo(0, 0);
      this.addAlert("If Global Credit Limit is checked ,It is Mandatory to enter Enter Office Field !!", 'danger');
      return false;
    }
    this.is.saveForm(this.creditform)
      .subscribe(data => {
        this.creditform = new CreditForm();
        alert("Credit Form Saved successfully !!");
        window.location.reload();
      });
  }

  public searchAcc(creditform) {
    console.log("YY " + creditform.searchAcctNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    this.is.getForm(creditform.searchAcctNo, user)
      .subscribe(data => {
        console.log("data " + data);
        this.creditform = data;
        console.log("data " + this.creditform.globalCreditLimit);
        console.log("isshow " + this.isShown);
        console.log("status " + this.creditform.creditformStatus);
        console.log("setAuthStatus " + this.creditform.authStatus);
        if (this.creditform.creditformStatus == "Pending With L1 Approver" && this.creditform.authStatus == "L1Access") {
          console.log("erter");
          if (this.creditform.userGroupId == this.creditform.firstLevelApp) {
            this.isShown = true;
            this.isShownSubmit = false;
            this.isAuth = false;
          }
          else {
            this.isShownSubmit = false;
            this.isAuth = true;
          }
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == "Pending With L1 Approver" && this.creditform.authStatus == "L1Reject") {
          console.log("erter");
          this.isShown = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == "Pending With L2 Approver" && this.creditform.authStatus == "L2Access") {
          console.log("erter");
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Pending With L2 Approver";
          this.thirdAppStatus = "Pending With L2 Approver";
          if (this.creditform.userGroupId == this.creditform.secLevelApp) {
            this.isShownL2 = true;
            this.isShownSubmit = false;

          }
          else {
            this.isAuth = true;
            this.isShownSubmit = false;
          }
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == 'Pending With L2 Approver' && this.creditform.authStatus == 'L2Reject') {
          console.log("erter");
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Pending With L2 Approver";
          this.thirdAppStatus = "Pending With L2 Approver";
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == "Pending With L3 Approver" && this.creditform.authStatus == "L3Access") {
          console.log("erter");
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.thirdAppStatus = "Pending With L3 Approver";
          if (this.creditform.userGroupId == this.creditform.thirdLevelApp) {
            this.isShownL3 = true;
            this.isShownSubmit = false;

          }
          else {
            this.isAuth = true;
            this.isShownSubmit = false;
          }
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == 'Pending With L3 Approver' && this.creditform.authStatus == 'L3Reject') {
          console.log("erter");
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.thirdAppStatus = "Pending With L3 Approver";
          this.isShownL3 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.authStatus == 'Unauth' || this.creditform.authStatus == null) {
          console.log("erter");
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.authStatus == 'Rejected' || this.creditform.authStatus == null) {
          console.log("erter");
          this.firstAppStatus = this.creditform.creditformStatus;
          this.secondAppStatus = this.creditform.creditformStatus;
          this.thirdAppStatus = this.creditform.creditformStatus;
          this.isShownSubmit = false;
          this.isRejected = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.authStatus == null) {
          console.log("erter");
          this.firstAppStatus = this.creditform.creditformStatus;
          this.secondAppStatus = this.creditform.creditformStatus;
          this.thirdAppStatus = this.creditform.creditformStatus;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        else if (this.creditform.creditformStatus == 'Approved' && this.creditform.authStatus == 'Approved') {
          console.log("erter");
          this.firstAppStatus = "Approved";
          this.secondAppStatus = "Approved";
          this.thirdAppStatus = "Approved";
          this.isShownSubmit = false;
          this.isApproverGrid = true;
          this.isApproved = true;
          if (this.creditform.recDaysIFS >= 45 || this.creditform.recDaysCNS >= 45 || this.creditform.recDaysDNS >= 45 || this.creditform.recDaysCLS >= 45 || this.creditform.recDaysIMS >= 45 ||
            this.creditform.recDaysTMS >= 45 || this.creditform.recDaysAUT >= 45 || this.creditform.recDaysVAS >= 45 || this.creditform.recDaysINR >= 45
            || this.creditform.recDaysOthers >= 45 || this.creditform.recDaysValidValues >= 45) {
            this.isLevel3App = true;
          }
        }
        console.log("isshowafter " + this.isShown);
        //alert("Credit Form Saved successfully !!");
      });
  }

  public approverForm(creditform, status) {
    console.log(status + "Hey " + creditform.accountNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    creditform.user = user;
    this.is.approverForm(this.creditform, status, user)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

  public approverFormLevel2(creditform, status) {
    console.log(status + "Hey " + creditform.accountNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    creditform.user = user;
    this.is.approverFormLevel2(this.creditform, status, user)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

  public approverFormLevel3(creditform, status) {
    console.log(status + "Hey " + creditform.accountNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    creditform.user = user;
    this.is.approverFormLevel3(this.creditform, status, user)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

}
