export class User {

    username: string;
    password: string;
    authStatus: boolean;
    firstLeveApprover: string;
    secondLevelApprover: string;
    thirdLevelApprover: string;
    groupId: boolean;
    custFrm: boolean;
    credFrm: boolean;
}