import { Component, OnInit } from '@angular/core';
import { CustomerForm } from './customerform.model';
import { InvoiceserviceService } from '../invoiceservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customerForm: CustomerForm = new CustomerForm();
  selectedFile: File;

  constructor(private is: InvoiceserviceService, private router: Router) { }

  ngOnInit() {
  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0];
    const formData = new FormData();
    formData.append('uploadedFile', this.selectedFile);
    this.is.uploadFiletoDir(formData)
      .subscribe(data => {
        alert("File Uploaded successfully !!");
      });
  }
  public saveForm() {
    this.customerForm.uploadFile = this.selectedFile;
    this.is.saveCustomerForm(this.customerForm)
      .subscribe(data => {
        this.customerForm = new CustomerForm();
        alert("Customer Form Saved successfully !!");
        window.location.reload();
      });
  }

}
