import { Component, OnInit } from '@angular/core';
import { CreditForm } from '../credit/creditform.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { InvoiceserviceService } from '../invoiceservice.service';
import { HttpResponse, HttpEventType } from '@angular/common/http';
import { Observable, Subject } from "rxjs";
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-credit',
  templateUrl: './credit.component.html',
  styleUrls: ['./credit.component.css']
})
export class CreditComponent implements OnInit {

  creditform: CreditForm = new CreditForm();
  selectedFile: File;
  constructor(private is: InvoiceserviceService, private router: Router) { }
  creditforms: CreditForm;
  isShown: boolean = false;
  isShownSubmit: boolean = true;
  isAuth: boolean = false;
  isShownL2: boolean = false;
  isRejected: boolean = false;
  isApproverGrid:boolean = false;
  isShownL3:boolean =false;
  isApproved:boolean =false;
  firstAppStatus:string ="Pending With L1 Approver";
  secondAppStatus:string ="Pending With L1 Approver";
  thirdAppStatus:string ="Pending With L1 Approver";
  ngOnInit() {
    var isLoggedin = sessionStorage.getItem('authenticatedUser');
    console.log(isLoggedin);
    // if (isLoggedin == 'false' || isLoggedin == null) {
    //   this.router.navigate(['/login']);
    //   console.log('checked');
    // }


  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0]
    console.log("Hefg " + this.selectedFile)
    const formData = new FormData();
    formData.append('uploadedFile', this.selectedFile);
    this.is.uploadFiletoDir(formData)
      .subscribe(data => {
        alert("File Uploaded successfully !!");
      });
  }

  public saveForm(creditform) {
    console.log("Hey " + creditform.accountNo);
    console.log("&&& " + this.selectedFile)
    creditform.uploadFile = this.selectedFile;
    console.log("^^^ " + creditform.uploadFile)
    this.is.saveForm(this.creditform)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form Saved successfully !!");
        window.location.reload();
      });
  }

  public searchAcc(creditform) {
    console.log("YY " + creditform.searchAcctNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    this.is.getForm(creditform.searchAcctNo, user)
      .subscribe(data => {
        console.log("data " + data);
        this.creditform = data;
        console.log("data " + this.creditform);
        console.log("isshow " + this.isShown);
        console.log("status " + this.creditform.creditformStatus);
        console.log("setAuthStatus " + this.creditform.authStatus);
        if (this.creditform.creditformStatus == "Pending With L1 Approver" && this.creditform.authStatus == "L1Access") {
          console.log("erter");
          if (user == this.creditform.firstLevelApp) {
            this.isShown = true;
            this.isShownSubmit = false;
            this.isAuth = false;
          }
          else {
            this.isShownSubmit = false;
            this.isAuth = true;
          }
          this.isApproverGrid =true;
        }
        else if (this.creditform.creditformStatus == "Pending With L1 Approver" && this.creditform.authStatus == "L1Reject") {
          console.log("erter");
          this.isShown = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid =true;
        }
        else if (this.creditform.creditformStatus == "Pending With L2 Approver" && this.creditform.authStatus == "L2Access") {
          console.log("erter");
          this.firstAppStatus="Approved";
          this.secondAppStatus="Pending With L2 Approver";
          this.thirdAppStatus="Pending With L2 Approver";
          if (user == this.creditform.secLevelApp) {
            this.isShownL2 = true;
            this.isShownSubmit = false;
            
          }
          else {
            this.isAuth = true;
            this.isShownSubmit = false;
          }
          this.isApproverGrid =true;
        }
        else if (this.creditform.creditformStatus == 'Pending With L2 Approver' && this.creditform.authStatus == 'L2Reject') {
          console.log("erter");
          this.firstAppStatus="Approved";
          this.secondAppStatus="Pending With L2 Approver";
          this.thirdAppStatus="Pending With L2 Approver";
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid =true;
        }
        else if (this.creditform.creditformStatus == "Pending With L3 Approver" && this.creditform.authStatus == "L3Access") {
          console.log("erter");
          this.firstAppStatus="Approved";
          this.secondAppStatus="Approved";
          this.thirdAppStatus="Pending With L3 Approver";
          if (user == this.creditform.thirdLevelApp) {
            this.isShownL3 = true;
            this.isShownSubmit = false;
            
          }
          else {
            this.isAuth = true;
            this.isShownSubmit = false;
          }
          this.isApproverGrid =true;
        }
        else if (this.creditform.creditformStatus == 'Pending With L3 Approver' && this.creditform.authStatus == 'L3Reject') {
          console.log("erter");
          this.firstAppStatus="Approved";
          this.secondAppStatus="Approved";
          this.thirdAppStatus="Pending With L3 Approver";
          this.isShownL3 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid =true;
        }
        else if (this.creditform.authStatus == 'Unauth' || this.creditform.authStatus == null) {
          console.log("erter");
          this.isShownL2 = false;
          this.isShownSubmit = false;
          this.isAuth = true;
          this.isApproverGrid =true;
        }
        else if (this.creditform.authStatus == 'Rejected' || this.creditform.authStatus == null) {
          console.log("erter");
          this.firstAppStatus=this.creditform.creditformStatus;
          this.secondAppStatus=this.creditform.creditformStatus;
          this.thirdAppStatus=this.creditform.creditformStatus;
          this.isShownSubmit = false;
          this.isRejected = true;
          this.isApproverGrid =true;
        }
        else if (this.creditform.creditformStatus == 'Approved' && this.creditform.authStatus == 'Approved') {
          console.log("erter");
          this.firstAppStatus="Approved";
          this.secondAppStatus="Approved";
          this.thirdAppStatus="Approved";
          this.isShownSubmit = false;
          this.isApproverGrid =true;
          this.isApproved =true;
        }
        console.log("isshowafter " + this.isShown);
        //alert("Credit Form Saved successfully !!");
      });
  }

  public approverForm(creditform, status) {
    console.log(status + "Hey " + creditform.accountNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    creditform.user = user;
    this.is.approverForm(this.creditform, status, user)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

  public approverFormLevel2(creditform, status) {
    console.log(status + "Hey " + creditform.accountNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    creditform.user = user;
    this.is.approverFormLevel2(this.creditform, status, user)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

  public approverFormLevel3(creditform, status) {
    console.log(status + "Hey " + creditform.accountNo);
    var user = sessionStorage.getItem('authenticatedUser');
    console.log("user " + user);
    creditform.user = user;
    this.is.approverFormLevel3(this.creditform, status, user)
      .subscribe(data => {
        creditform = new CreditForm();
        alert("Credit Form is processed successfully !!");
        window.location.reload();
      });

  }

}
