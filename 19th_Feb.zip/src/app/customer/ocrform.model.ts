
export class OCRForm {
    ocr: string;
    compCode: string;
    approver: string;
    createdBy: string;
    createdDate: Date;
   
}