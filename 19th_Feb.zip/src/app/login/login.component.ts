import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../login/auth.service';
import { User } from '../login/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: User = new User();
  username: string;
  password : string;
  errorMessage = 'Invalid Credentials';
  successMessage: string;
  invalidLogin = false;
  loginSuccess = false;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthService) { }

  ngOnInit() {
    localStorage.clear();
    sessionStorage.clear();
  }

  handleLogin() {
    this.authenticationService.authenticationService(this.username, this.password).subscribe((result)=> {
      console.log("hhh "+result);
      this.user= result;
      console.log("res "+this.user);
     // var result = this.user.authStatus;
      console.log("res "+result);
      console.log("type "+typeof this.user.authStatus);
      if(this.user.authStatus) {
        // console.log("ddd"+result);
        this.invalidLogin = false;
        this.loginSuccess = true;
        //localStorage.setItem('isLoginSuccess','true');
        this.successMessage = 'Login Successful.';
        this.router.navigate(['/dashboard']);
      } else {
        //auth failed
        this.invalidLogin = true;
      }
     
    }, () => {
      console.log("hell");
       this.invalidLogin = true;
      // this.loginSuccess = false;
     // localStorage.setItem('isLoginSuccess','false');
     this.successMessage = 'Invalid Credentials';
        this.router.navigate(['/login']);
    });      
  }

}
