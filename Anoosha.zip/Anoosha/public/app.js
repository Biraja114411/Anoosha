var app = angular.module("mainApp", ["ngRoute", "ngResource"]);
app.config(function ($routeProvider, $locationProvider) {
    $routeProvider
        .when('/', {
            templateUrl: "home/home.html",
            controller: "homeController"
        })
        .otherwise({
            templateUrl: "partials/home.html",
            controller: "homeController"
        });
    $locationProvider.html5Mode({
        enabled: true, requireBase: true
    })

})
app.controller("homeController", ["$scope", "$http", "$resource", function ($scope, $http, $resource) {
    $scope.event = [];
    $scope.submitForm = function (form) {
        $scope.event.push(angular.copy(form));
        console.log($scope.event);
    }
}]);