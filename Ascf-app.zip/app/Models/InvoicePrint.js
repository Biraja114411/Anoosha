'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')
const DB = use('Database')
let dateFormat = require('dateformat');
let now = new Date();
let today = dateFormat(now, 'yymmdd');
//  let today = '200122';
let time_now = dateFormat(now, 'HHMMss');
const FTPS = require('ftps');
const { exec } = require("child_process");
const Utility = use('App/Models/Utility')

class InvoicePrint extends Model {


  async getUser() {
    let query = DB.table('IDMSDB.AUSR_REC')
                .select('CITY_CODE')
                .where('USER_ID', 'OAKY2K00')
    return query;
  }

  async getOldReqNum() {
    //TODO: LOCATION AND REPORT_NUMBER based on UI Value
    var query = DB.table('IDMSDB.RQST_REC')
      .where('REQUESTING_LOC', 'OAK   ')
      .where('REQUEST_MADE_DATE', today)
      .getMax('REPORT_REQUEST_NUMBER')

    return query;
  }

  async getDBKey() {
    let query = DB.table('DUAL')
                .select('IDMSDB.QJOB_RQST_QQST_SEQUENCE.NEXTVAL')
    return query;
  }

  async findInRQST(dbKey) {
    return DB.table('IDMSDB.RQST_REC')
      .where('DBKEY', dbKey)
  }

  async getOldDBKey() {
    while (true) {
      let dbkey = await this.getDBKey();
      console.log(dbkey)
      if(dbkey.length) {
        let validDbKey = await this.findInRQST(dbkey[0].NEXTVAL)
        console.log(validDbKey)
        if(!validDbKey.length) {
          return dbkey;
          break;
        }
      }
    }
  }

  async getHdr(data) {
    return DB.table('A1PRD.INVOICE_HDR')
      .where('INVOICE_NBR', data.invoice_list[0].value)
      .select('ORIG_PORT_CD', 'REM_CTY_CD').limit(1);
  }

  async getGst(port_code) {
    return DB.table('A1PRD.PORT').select(
      'ADMIN_CTY_CD'
    ).where('PORT_CD', port_code).limit(1);
  }

  async insertRec(data, config, user, new_req_num, new_db_key) {
    const utility = new Utility()
    let gstEnabled = false;
    // check GST eligibility
    var hdr = await this.getHdr(data)

    let gst = await this.getGst(hdr[0].ORIG_PORT_CD)

    if(gst[0].ADMIN_CTY_CD === 'IN' || hdr[0].REM_CTY_CD === 'IN') {
      gstEnabled = true;
    }

    console.log(new_req_num)
    var query = DB.table('IDMSDB.RQST_REC').insert(
      {
        LAST_USER_ID: null,
        LAST_UPDATE_DATE: null,
        LAST_RACN: null,
        REQUESTING_LOC: utility.fillSpaces(config.print_city, 6),
        REQUEST_MADE_DATE: today,
        REPORT_REQUEST_NUMBER: new_req_num,
        REPORT_NUMBER: gstEnabled ? 'A1OI03R1' : 'A1OI02R1',
        USER_ID: user.CITY_CODE,
        USER_LOC: 'OAK   ',
        USER_DEPT_CODE: '   ',
        CANCEL_USER_ID: '        ',
        REQUEST_MADE_TIME: time_now,
        PROCESS_BEGIN_DATE: '000000',
        PROCESS_BEGIN_TIME: '000000',
        PROCESS_END_DATE: '000000',
        PROCESS_END_TIME: 0,
        PROCESS_RETURN_CODE: 0,
        PROCESSED_DSN: ' ',
        FREQUENCY_CODE: utility.fillSpaces(config.print_report_frequency, 4),
        PRINT_AT_CITY_CODE: utility.fillSpaces(config.print_city, 3),
        PRINT_AT_SITE_CODE: ' ',
        PRINT_AT_PRINTER_ID: utility.fillSpaces(config.print_id, 3),
        PRINT_PRIORITY_CODE: config.print_priority,
        FORM_TYPE_CODE: utility.fillSpaces(config.print_nbr, 4),
        SETS_TO_PRINT_COUNT: utility.fillSpaces(config.print_sets, 4),
        JOB_NAME: gstEnabled ? 'A#123OIP' : 'A#123O'+Math.random(Math.floor(Math.random()*100)),
        JOB_NBR: '        ',
        SCHED_FLG: null,
        SCHED_RUN_DATE: null,
        SCHED_RUN_TIME: null,
        DATE_CC: null,
        OCCURS_COUNT: 0,
        COMMENT_75_1: config.comments,
        COMMENT_75_2: ' ',
        DBKEY: new_db_key
      });

      return query;
  }

  async getOldOrderNum(data) {
    let gstEnabled = false;
    var hdr = await this.getHdr(data)
    let gst = await this.getGst(hdr[0].ORIG_PORT_CD)

    if(gst[0].ADMIN_CTY_CD === 'IN' || hdr[0].REM_CTY_CD === 'IN') {
      gstEnabled = true;
    }
    var query = DB.table('IDMSDB.REPT_RQST_SET')
      .where('REPT_REPORT_NUMBER', gstEnabled ? 'A1OI02R1' : 'A1OI03R1')
      .getMax('ORDER_NUMBER')

    return query;
  }

  async insertRqstSet(new_req_num, order_num) {
    let gstEnabled = false;
    var hdr = await this.getHdr(data)
    let gst = await this.getGst(hdr[0].ORIG_PORT_CD)

    if(gst[0].ADMIN_CTY_CD === 'IN' || hdr[0].REM_CTY_CD === 'IN') {
      gstEnabled = true;
    }
    var query = DB.table('IDMSDB.REPT_RQST_SET').insert(
    {
      REPT_REPORT_NUMBER: gstEnabled ? 'A1OI02R1' : 'A1OI03R1',
      RQST_REQUESTING_LOC: 'OAK   ',
      RQST_REQUEST_MADE_DATE: today,
      RQST_REPORT_REQUEST_NUMBER: new_req_num,
      ORDER_NUMBER: order_num
    });

    return query;
  }

  async getRqcrDBKey() {
    let query = DB.table('DUAL')
      .select('IDMSDB.RQCR_SEQUENCE.NEXTVAL')
    return query;
  }

  async findInRQCR(dbKey) {
    return DB.table('IDMSDB.RQCR_REC')
      .where('DBKEY', dbKey)
  }

  async getOldRqcrDBKey() {
    while (true) {
      let dbkey = await this.getRqcrDBKey();
      console.log(dbkey)
      if(dbkey.length) {
        let validDbKey = await this.findInRQCR(dbkey[0].NEXTVAL)
        console.log(validDbKey)
        if(!validDbKey.length) {
          return dbkey;
          break;
        }
      }
    }
    return query;
  }
  async createRqcr(data, config, req_num, dbkey) {
    const utility = new Utility();
    var keyList = [
      'INVOICE NBR      :            ',
      '                 :            ',
      '                 :            ',
      'INV  RANGE ONE   :            ',
      'INV  RANGE TWO   :            ',
      'PRINT TYPE/FORMDEF,PAGEDEF :  ',
      'TO RMT/CURR TEXT REQ........: ',
      'USER ID.....................: ',
      'LOCAL TIME ZONE/INVOICE TYPE: ',
      'FAX RECIPIENT COMPANY.......: ',
      'FAX ATTN....................: ',
      'EMAIL ID....................: ',
      'FAX NBR.....................: ',
      'EMAIL/FAX FLAG..............: ',
      'DSN SUFFIX, XMIT JOB........: '
    ];

    var valueList;

    if(data.selection_type === 'single') {
      valueList = [
        data.invoice_list[0].value+':'+data.invoice_list[1] ? data.invoice_list[1].value : '',
        data.invoice_list[2] ? data.invoice_list[2].value : '          :'+data.invoice_list[3] ? data.invoice_list[3].value : '',
        data.invoice_list[4] ? data.invoice_list[4].value : '          :'+data.invoice_list[5] ? data.invoice_list[5].value : '',
        data.invoice_list[6] ? data.invoice_list[6].value : '          -'+data.invoice_list[7] ? data.invoice_list[7].value : '',
        data.invoice_list[8] ? data.invoice_list[8].value : '          -'+data.invoice_list[9] ? data.invoice_list[9].value : '',
        config.final?'F':'D'+' '+config.reprint?'R':' '+' Y A1OIGF A1OIGF I D                         ',
        '         YN                                     ',
        'OAKY2K00                                        ',
        '+00 OI                                          ',
        '                                                ',
        '                                                ',
        utility.fillSpaces(config.email, 48),
        '                       N                        ',
        'E                                               ',
        'D200116.T184355.LW01O, A#123X02                 '
      ];
    } else {
      valueList = [
        '          :                                     ',
        '          :                                     ',
        '          :                                     ',
        data.r1_lower_limit+'-'+data.r1_upper_limit,
        data.r2_lower_limit ? data.r2_lower_limit : '          '+'-'+data.r2_upper_limit ? data.r2_upper_limit : '',
        config.final?'F':'D'+' '+config.reprint?'R':' '+' Y A1OIGF A1OIGF I D                         ',
        '         YN                                     ',
        'OAKY2K00                                        ',
        '+00 OI                                          ',
        '                                                ',
        '                                                ',
        utility.fillSpaces(config.email, 48),
        '                       N                        ',
        'E                                               ',
        'D200116.T184355.LW01O, A#123X02                 '
      ];
    }



    for(var i=0; i<15; i++) {

      var new_db_key = (parseInt(dbkey) + i + 1).toString();
      var maxRun = (8 - dbkey.toString().length);
      for(var j = 0; j < maxRun; j++) {
        new_db_key = '0' + new_db_key;
      }
      var query = await DB.table('IDMSDB.RQCR_REC').insert(
        {
          LAST_USER_ID: null,
          LAST_UPDATE_DATE: null,
          LAST_RACN: null,
          SELECT_INDEX: i + 1,
          SELECT_CRITERIA_NAME: keyList[i],
          SELECT_CRITERIA_VALUE: valueList[i],
          DBKEY: new_db_key
        }
      );

      var query1 = await DB.table('IDMSDB.RQST_RQCR_SET').insert(
        {
          RQST_REQUESTING_LOC: 'OAK   ',
          RQST_REQUEST_MADE_DATE: today,
          RQST_REPORT_REQUEST_NUMBER: req_num,
          RQCR_DBKEY: new_db_key,
          ORDER_NUMBER: i + 1
        }
      )

    }

    return 'Insert success';
  }

  async createJCL(req_num) {
    //TODO: Set up dynamic email
    var p = 'OAK   '+today+req_num;
    var q = 'A#123O11'+'.A'+time_now;
    var d = 'D'+today+'.T'+time_now+'.LW01O';
    var jcl = `//A#123O11 JOB (1099,,,,,,,,,APL,OAK,OAKY2K00,A1OI02R1,OIMM),           00010008
//  'INVOICE PRINT',CLASS=G,MSGCLASS=Z,REGION=8M,USER=A#CRQ
//*                                                                     00004
/*JOBPARM LINECT=0
/*ROUTE PRINT SAR                                                       00042048
/*OUTPUT 1111 DEST=RMT099                                               00003
//*                                                                     00100001
//JOBLIB   DD  DSN=ADBAPRD.APRD.DBALOAD,DISP=SHR
//         DD  DSN=ADBAIDM.PROD.LOADLIB,DISP=SHR                        00104008
//         DD  DSN=APASPRD.LOADLIB,DISP=SHR
//         DD  DSN=SYS4.EDS.LOAD,DISP=SHR                               00150001
//         DD  DSN=SYS2.SMARTJS.DCALOAD,DISP=SHR
//*
//**********************************************************************
//* THIS JOB STEP RUNS THE CA-11 RUN MANAGER (RMS) PROCEDURE.
//**********************************************************************
//JS010  EXEC A123P022,RE79DR=ASRE79DR,SYSID=A,
//          P='${p}',Q='${q}',
//          RPTNBR=A1OI02R1,
//          D='${d}',
//          TORMT='',
//          FORMDEF='A1OIGF',
//          PAGEDEF='A1OIGF'
//*                                                                             `;

    var file_name = 'A#123O11.jcl';
    const Drive = use('Drive');
    await Drive.put(file_name, Buffer.from(jcl))

    var ftps = new FTPS({
      host: '10.128.205.11', // required
      username: 'didubey', // Optional. Use empty username for anonymous access.
      password: 'Apllsep1', // Required if username is not empty, except when requiresPassword: false
      protocol: 'sftp', // Optional, values : 'ftp', 'sftp', 'ftps', ... default: 'ftp'
      // protocol is added on beginning of host, ex : sftp://domain.com in this case
      port: 22, // Optional,
      autoConfirm: true
    });


    var path = '/Users/ashik/webapps/ACSF/invoice/tmp/'
    ftps.cd('/tmp').addFile(path + file_name)
      .exec("mfbsijcl /lMFESJES2 /j'/tmp/A$123O11.jcl'", (error, stdout, stderr) => {
      if (error) {
        console.log(`error: ${error.message}`);
        return;
      }
      if (stderr) {
        console.log(`stderr: ${stderr}`);
        return;
      }
      console.log(`stdout: ${stdout}`);
    });

    return 'success';
  }

  async validateInvoice(data) {
    console.log('api data : ', data)
    let query = DB.table('A1PRD.INVOICE_HDR')
                .whereIn('INVOICE_NBR', data.data)
                .select('INVOICE_NBR', 'INVOICE_STATUS_CD')
    return query;
  }

  async printerValidation(config) {
    console.log(config.print_id, config.print_city)
    if(config.print_type == 'H') {
      let query = DB.table('IDMSDB.PRNT_REC as A')
        .leftOuterJoin('IDMSDB.ZLOC_PRNT_SET as B', 'A.DBKEY', 'B.PRNT_DBKEY')
        .where('A.PRINTER_ID', config.print_id)
        .where('B.CITY_CODE', config.print_city)

      return query;
    }
  }

}

module.exports = InvoicePrint
