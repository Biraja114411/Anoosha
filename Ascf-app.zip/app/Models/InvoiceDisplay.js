'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')
const DB = use('Database')
const Utility = use('App/Models/Utility')

class InvoiceDisplay extends Model {
  async getAdminCountry(port_cd) {
    console.log(port_cd)
    let query = DB.table('A1PRD.PORT').select(
      'ADMIN_CTY_CD'
    ).where('PORT_CD', port_cd).limit(1);
    return query;
  }
  async oiLoadIH(inv_num, so_num, gst_num) {
    let query = DB.table('A1PRD.INVOICE_HDR').select(
      'INVOICE_NBR',
      'GST_INV_NBR',
      'ACS_CUST_ACCT_CD',
      'ORIG_PORT_CD',
      'INVOICE_STATUS_CD',
      'OI_FNL_PRT_RD_FLG',
      "INVOICE_DT",
      'VOYAGE_NBR',
      'FEEDER_VESSEL_NME',
      'MOTHER_VESSEL_NME',
      'SHPMT_ORIG_PORT_CD',
      'FEEDER_VV_NBR',
      'MOTHER_VV_NBR',
      'SAILING_DT',
      'DEST_PORT_CD',
      'TR_TO_PORT_CD',
      'BILLING_CD',
      'BILLING_NAME',
      'BILLING_ADDR1',
      'BILLING_ADDR2',
      'BILLING_ADDR3',
      'BILLING_ADDR4',
      'BILL_CITY_NME',
      'BILL_STATE_CD',
      'BILL_POSTAL_CD',
      'BILL_CTY_CD',
      'RRS_ACCT_CD',
      'PAY_CURRENCY_CD',
      'SEC_PAY_CURR_CD',
      'SEC_EXCHANGE_RATE',
      'OLD_INVOICE_NBR',
      'INVC_SEQ_NBR',
      'NEW_INVOICE_NBR',
      'TRF_TO_PORT_DT',
      'REMIT_CD',
      'REMIT_NAME',
      'REMIT_ADDR1',
      'REMIT_ADDR2',
      'REMIT_ADDR3',
      'REMIT_ADDR4',
      'EOS_EXTRACT_FLG',
      'MAN_INVOICE_FLG',
      'RRS_INTER_TSTAMP',
      'RRS_FULLPAY_TSTAMP',
      'NETTRAC_TRANS_TS',
      'IN_BRK_LEVEL1_CD',
      'IN_BRK_VAL_LEVEL1',
      'IN_BRK_VAL_LEVEL2',
      'REMIT_CITY_NME',
      'REMIT_STATE_CD',
      'REMIT_POSTAL_CD',
      'REM_CTY_CD',
      'EDI_STATUS_CD',
      'EDI_AIF_TSTAMP',
      'INLAND_INV_FLG',
      'CREATE_USER_ID_CD',
      'CREATE_LOCAL_TS',
      'LST_UPD_USER_ID_CD',
      'LST_UPD_LOCAL_TS',
      'F_PRT_USER_ID_CD',
      'LST_PRT_USER_ID_CD',
      'VOID_REASON_CD',
      'LSS_INV_NBR',
      'LSS_STATUS_FLG',
      'LSS_STS_CD');

    if(inv_num.trim().length) {
      query.where('INVOICE_NBR', inv_num);
    }

    if(so_num.trim().length) {
      query.where('LSS_INV_NBR', inv_num);
    }

    if(gst_num.trim().length) {
      query.where('GST_INV_NBR', inv_num);
    }

    return query;
  }

  async oiLoadIG(inv_num, so_num, gst_num) {
    let query = DB.table('A1PRD.INVOICE_HDR as A')
      .leftOuterJoin('A1PRD.INVOICE_CHRG_DTL as B', 'A.INVOICE_NBR', 'B.INVOICE_NBR')
      .select(
        'A.INVOICE_NBR',
        'A.ACS_CUST_ACCT_CD',
        'A.INVOICE_DT',
        'A.SERVICE_DATE',
        'A.ORIG_PORT_CD',
        'A.VOYAGE_NBR',
        'A.DEST_PORT_CD',
        'A.INVOICE_STATUS_CD',
        'A.IN_BRK_VAL_LEVEL1',
        'A.IN_BRK_VAL_LEVEL2',
        'A.TR_TO_PORT_CD',
        'A.CR_DR_FL',
        'B.AMOUNT_2',
        'B.INV_CHRG_TAX_AMT',
        'B.CURRENCY_CD',
        'A.VAT_ID_NBR',
        'B.AMOUNT_2',
        'B.INV_CHRG_TAX_AMT',
        'A.SEC_PAY_CURR_CD',
        'B.SEQ_NBR',
        'B.CHARGE_CD',
        'B.CHARGE_DESC',
        'B.CURRENCY_CD',
        'B.UNIT_CD_1',
        'B.QUANTITY_1',
        'B.RATE',
        'B.MAN_CHRG_FLG',
        'B.SERVICE_TYPE_CD',
        'B.INVC_CHRG_REF_NBR',
        'B.AMOUNT_1',
        'B.EXCHANGE_RATE',
        'B.AMOUNT_2',
        'B.INV_CHRG_TAX_AMT',
        'B.CURRENCY_CD',
        'B.LOAD_TYPE_CD',
        'B.INV_CHRG_TAX_CD',
        'B.INV_CHRG_TAX_PCT',
        'B.INV_CHRG_TAX_AMT',
        'B.REV_VAT_FLG',
        'B.CGST_TAX_PCT',
        'B.SGST_TAX_PCT',
        'B.UTGST_TAX_PCT',
        'B.IGST_TAX_PCT',
        'B.DISCOUNT_PCT',
        'B.CGST_TAX_AMT',
        'B.SGST_TAX_AMT',
        'B.UTGST_TAX_AMT',
        'B.IGST_TAX_AMT',
        'B.DISCOUNT_AMT',
        'A.GST_STS_TSTAMP',
      );

    if(inv_num.trim().length) {
      query.where('A.INVOICE_NBR', inv_num);
    }

    if(so_num.trim().length) {
      query.where('A.LSS_INV_NBR', inv_num);
    }

    if(gst_num.trim().length) {
      query.where('A.GST_INV_NBR', inv_num);
    }

    return query;
  }

  async oiLoadID(inv_num, so_num, gst_num) {
    let query = DB.table('A1PRD.INVOICE_HDR as A')
      .leftOuterJoin('A1PRD.INVOICE_CHRG_DTL as B', 'A.INVOICE_NBR', 'B.INVOICE_NBR')
      .select(
        'A.INVOICE_NBR',
        'A.ACS_CUST_ACCT_CD',
        'A.INVOICE_DT',
        'A.SERVICE_DATE',
        'A.ORIG_PORT_CD',
        'A.VOYAGE_NBR',
        'A.DEST_PORT_CD',
        'A.INVOICE_STATUS_CD',
        'A.IN_BRK_VAL_LEVEL1',
        'A.IN_BRK_VAL_LEVEL2',
        'A.TR_TO_PORT_CD',
        'B.CHARGE_CD',
        'B.CHARGE_DESC',
        'B.SEQ_NBR',
        'B.SERVICE_TYPE_CD',
        'B.LOAD_TYPE_CD',
        'B.GOH_FLAG',
        'B.QUANTITY_1',
        'B.UNIT_CD_1',
        'B.VALUE_OF_UNIT_1',
        'B.QUANTITY_2',
        'B.UNIT_CD_2',
        'B.VALUE_OF_UNIT_2',
        'B.RATE',
        'B.CURRENCY_CD',
        'B.CHARGE_PORT_CD',
        'B.AMOUNT_1',
        'B.CALC_METHOD_CD',
        'B.MIN_ADJ_FLG',
        'B.RATE_METHOD_CD',
        'B.MAN_CHRG_FLG',
        'A.PAY_CURRENCY_CD',
        'B.REV_VAT_FLG',
        'B.MAX_ADJ_FLG',
        'B.EXCHANGE_RATE',
        'B.INV_CHRG_TAX_PCT',
        'B.INV_CHRG_TAX_AMT',
        'B.AMOUNT_2',
        'B.INV_CHRG_TAX_AMT',
        'B.INV_CHRG_TAX_CD',
        'B.CREATE_USER_ID_CD',
        'B.CREATE_TSTAMP',
        'B.LST_UPD_USER_ID_CD',
        'B.LST_UPD_TSTAMP'
      );

    if(inv_num.trim().length) {
      query.where('A.INVOICE_NBR', inv_num);
    }

    if(so_num.trim().length) {
      query.where('A.LSS_INV_NBR', inv_num);
    }

    if(gst_num.trim().length) {
      query.where('A.GST_INV_NBR', inv_num);
    }

    return query;
  }

  async oiLoadIM(inv_num, so_num, gst_num) {
    let query = DB.table('A1PRD.INVOICE_HDR as A')
      .leftOuterJoin('A1PRD.INVOICE_CHRG_DTL as B', 'A.INVOICE_NBR', 'B.INVOICE_NBR')
      .select(
        'A.INVOICE_NBR',
        'A.ACS_CUST_ACCT_CD',
        'A.INVOICE_DT',
        'A.SAILING_DT',
        'A.ORIG_PORT_CD',
        'A.TR_TO_PORT_CD',
        'A.VOYAGE_NBR',
        'A.DEST_PORT_CD',
        'A.INVOICE_STATUS_CD',
        'A.PAY_CURRENCY_CD',
        'A.SEC_PAY_CURR_CD',
        'A.SEC_EXCHANGE_RATE',
        'A.BILLING_CD',
        'A.BILL_CTY_CD',
        'A.REMIT_CD',
        'A.REM_CTY_CD',
        'A.RRS_INTER_TSTAMP',
        'A.EOS_EXTRACT_FLG',
        'A.EOS_LST_EXTRACT_TS',
        'A.TRF_TO_PORT_DT',
        'A.INVOICE_PORT_CD',
        'B.INVOICE_NBR',
        'B.SEQ_NBR',
        'B.MAN_CHRG_FLG',
        'B.SERVICE_TYPE_CD',
        'B.CHARGE_CD',
        'B.CHARGE_DESC',
        'B.CALC_METHOD_CD',
        'B.RATE_METHOD_CD',
        'B.QUANTITY_1',
        'B.QUANTITY_2',
        'B.UNIT_CD_1',
        'B.UNIT_CD_2',
        'B.VALUE_OF_UNIT_1',
        'B.VALUE_OF_UNIT_2',
        'B.RATE',
        'B.AMOUNT_1',
        'B.AMOUNT_2',
        'B.CURRENCY_CD',
        'B.EXCHANGE_RATE',
        'B.MIN_ADJ_FLG',
        'B.CHARGE_PORT_CD',
        'B.LOAD_TYPE_CD',
        'B.GOH_FLAG',
        'B.CREATE_USER_ID_CD',
        'B.CREATE_TSTAMP',
        'B.LST_UPD_USER_ID_CD',
        'B.LST_UPD_TSTAMP',
        'B.INV_CHRG_TAX_PCT',
        'B.INV_CHRG_TAX_AMT',
        'B.REV_VAT_FLG',
        'B.INV_CHRG_TAX_CD',
        'B.INVC_CHRG_REF_NBR',
        'B.CHRG_TYPE_CD',
        'B.EXCHANGE_FLG',
        'A.SERVICE_DATE',
        'A.GST_INV_NBR',
        'A.GST_STS_CD',
        'B.CGST_TAX_PCT',
        'B.SGST_TAX_PCT',
        'B.UTGST_TAX_PCT',
        'B.IGST_TAX_PCT',
        'B.DISCOUNT_PCT',
        'B.CGST_TAX_AMT',
        'B.SGST_TAX_AMT',
        'B.UTGST_TAX_AMT',
        'B.IGST_TAX_AMT',
        'B.DISCOUNT_AMT',
        'A.GST_STS_TSTAMP',
        'A.CR_DR_FLG',
        'A.BILL_STATE_CD',
        'A.RRS_ACCT_CD',
        'A.REF_INV_NBR',
        'B.CHARGE_LOC',
        'B.ACTIVITY_IND',
        'A.LSS_INV_NBR'
      );

    if(inv_num.trim().length) {
      query.where('A.INVOICE_NBR', inv_num);
    }

    if(so_num.trim().length) {
      query.where('A.LSS_INV_NBR', inv_num);
    }

    if(gst_num.trim().length) {
      query.where('A.GST_INV_NBR', inv_num);
    }

    return query;
  }

  async oiLoadIR(inv_num, so_num, gst_num) {
    let query = DB.table('A1PRD.INVOICE_HDR as A')
      .leftOuterJoin('A1PRD.INVOICE_REMARKS as B', 'A.INVOICE_NBR', 'B.INVOICE_NBR')
      .select(
        'A.INVOICE_NBR',
        'A.ACS_CUST_ACCT_CD',
        'A.INVOICE_DT',
        'A.ORIG_PORT_CD',
        'A.VOYAGE_NBR',
        'A.DEST_PORT_CD',
        'A.INVOICE_STATUS_CD',
        'A.PAY_CURRENCY_CD',
        'A.TR_TO_PORT_CD',
        'A.IN_BRK_VAL_LEVEL1',
        'A.IN_BRK_VAL_LEVEL2',
        'A.SEC_PAY_CURR_CD',
        'A.SEC_EXCHANGE_RATE',
        'A.RRS_INTER_TSTAMP',
        'A.EOS_EXTRACT_FLG',
        'A.EOS_LST_EXTRACT_TS',
        'A.INLAND_BOL_TXT',
        'A.OLD_INVOICE_NBR',
        'A.INVC_SEQ_NBR',
        'A.INLAND_INV_FLG',
        'B.SEQ_NBR',
        'B.SYS_GEN_FLG',
        'B.PRINT_FLG',
        'B.REMARKS',
        'B.LST_UPD_TSTAMP',
        'A.LSS_INV_NBR',
        'A.LSS_STATUS_FLG',
        'A.LSS_STS_CD'
      );

    if(inv_num.trim().length) {
      query.where('A.INVOICE_NBR', inv_num);
    }

    if(so_num.trim().length) {
      query.where('A.LSS_INV_NBR', inv_num);
    }

    if(gst_num.trim().length) {
      query.where('A.GST_INV_NBR', inv_num);
    }

    return query;
  }

  async oiLoadTemplates(inv_num, so_num, gst_num) {
    let query = DB.table('A1PRD.LSS_INV_TEMPLETES')
      .select(
        'LSS_INV_NBR',
        'SEQ_NBR',
        'INVOICE_NBR',
        'ACS_VOY',
        'CLP_NBR',
        'BOOKING',
        'PO_NBR',
        'STYLE',
        'SUB_STYLE',
        'BL_NBR',
        'CARRIER_CD',
        'HBL_BL_NBR',
        'ADOD',
        'AMOUNT',
        'ASAP',
        'RMK',
        'INCOTERMS',
        'BRAND',
        'CARTON',
        'COLLECT',
        'CONSIGNEE',
        'CNTR_NBR',
        'CTR_SIZE',
        'COST_USD',
        'CPO',
        'CUSTOMER_CODE',
        'DIVISION_NBR',
        'FINAL_DEST',
        'GL_CONSOLIDATION',
        'GL_DEST_DRAYAGE',
        'GL_OCF_AND_ACC',
        'HBL_NBR',
        'INT_PO',
        'LIN',
        'MGFEE',
        'PKGS',
        'UOM',
        'PLANT_CODE',
        'REF_NBR',
        'SHIP_TO',
        'SHIPMENT_BL_NBR',
        'SHIPMENT_NBR',
        'SHIPPER_NAME',
        'SWY_PO_NO',
        'CBM',
        'ROUTE',
        'KGS',
        'WHC',
        'LI_BL',
        'LI_SO',
        'LI_EXCHANGE_RATE',
        'LI_CNTR_NBR',
        'LI_HBL_NBR',
        'LI_FCR_NBR',
        'CREATE_USER_ID_CD',
        'CREATE_TSTAMP',
        'LST_UPD_USER_ID_CD',
        'LST_UPD_TSTAMP'
      )
      .whereNotNull('LSS_INV_NBR');

    if(inv_num.trim().length) {
      query.where('INVOICE_NBR', inv_num);
    }

    if(so_num.trim().length) {
      console.log('so taken')
      query.where('LSS_INV_NBR', inv_num);
    }

    query.where('SEQ_NBR', '>=', 0);

    query.orderBy('LSS_INV_NBR').orderBy('INVOICE_NBR').orderBy('SEQ_NBR');

    return query;
  }

  async liLoadLC(inv_num, type) {
    let query = DB.table('A1PRD.LCL_INVC_HEADER as H')
      .leftOuterJoin('A1PRD.LCL_INVC_CHRG_DTL as D', 'H.INVOICE_NBR', 'D.INVOICE_NBR')
      .select(
        'H.INVOICE_NBR',
        'H.ADM_COUNTRY_CD',
        'H.CUST_ACCT_CD',
        'D.CUST_ACCT_CD',
        'H.SHIPPER_CD',
        'D.SHIPPER_CD',
        'H.STATUS_CD',
        'H.INVOICE_DT',
        'H.VOYAGE_NBR',
        'D.VOYAGE_NBR',
        'H.INVC_LOAD_PORT_CD',
        'D.LOAD_PORT_CD',
        'H.DEST_PORT_CD',
        'D.DEST_PORT_CD',
        'H.PRI_PAY_CRNCY_CD',
        'H.RRS_INTFC_L_TSTAMP',
        'D.WAREHOUSE_CD',
        'H.SCNDY_PAY_CRNCY_CD',
        'H.EXCHANGE_RATE',
        'D.SEQUENCE_NBR',
        'D.RATE_METHOD_CD',
        'D.CHARGE_CD',
        'D.CHARGE_DESC_TXT',
        'D.CHARGE_CRNCY_CD',
        'D.UOM_1_CD',
        'D.CHARGE_1_QTY',
        'D.CHARGE_RATE',
        'D.MANUAL_CHARGE_FLG',
        'D.CHARGE_ADJUST_CD',
        'D.CHARGE_AMT',
        'D.CHARGE_TAX_AMT',
        'D.EXCHANGE_RATE',
        'D.EXCHANGE_FLG',
        'D.PAY_AMT',
        'D.PAY_TAX_AMT',
        'D.LST_UPD_USER_ID_CD',
        'D.LST_UPD_TSTAMP',
        'D.SERVICE_TYPE_CD',
        'H.MANUAL_INVOICE_FLG',
        'H.CR_CLP_SYNC_FLG',
        'H.LST_UPD_TSTAMP',
        'H.SHPMT_REQD_FLG',
        'D.TAX_PCT',
        'D.TAX_CD',
        'H.LSS_INV_NBR',
        'H.LSS_STATUS_FLG',
        'H.CR_DR_FL',
        'H.REMIT_CD',
        'D.CHARGE_PORT_CD'
      );

    if(type == 'lss_num') {
      query.where('H.LSS_INV_NBR', inv_num);
    }

    if(type == 'invoice_num') {
      query.where('H.INVOICE_NBR', inv_num);
    }

    return query;
  }

  async liLoadLD(inv_num, type) {
    let query = DB.table('A1PRD.LCL_INVC_HEADER as H')
      .leftOuterJoin('A1PRD.LCL_INVC_CHRG_DTL as D', 'H.INVOICE_NBR', 'D.INVOICE_NBR')
      .select(
        'H.INVOICE_NBR',
        'H.ADM_COUNTRY_CD',
        'H.CR_CLP_SYNC_FLG',
        'H.CUST_ACCT_CD',
        'D.CUST_ACCT_CD',
        'H.SHIPPER_CD',
        'D.SHIPPER_CD',
        'H.STATUS_CD',
        'H.INVOICE_DT',
        'H.VOYAGE_NBR',
        'D.VOYAGE_NBR',
        'H.INVC_LOAD_PORT_CD',
        'D.LOAD_PORT_CD',
        'H.DEST_PORT_CD',
        'D.DEST_PORT_CD',
        'H.WAREHOUSE_CD',
        'H.PRI_PAY_CRNCY_CD',
        'H.RRS_INTFC_L_TSTAMP',
        'D.SEQUENCE_NBR',
        'D.SERVICE_TYPE_CD',
        'D.LOAD_TYPE_CD',
        'D.GOH_FLG',
        'D.CHARGE_PORT_CD',
        'D.CHARGE_CD',
        'D.CHARGE_DESC_TXT',
        'D.CHARGE_ADJUST_CD',
        'D.MANUAL_CHARGE_FLG',
        'D.CALCN_METHOD_CD',
        'D.RATE_METHOD_CD',
        'D.CHARGE_1_QTY',
        'D.CHARGE_2_QTY',
        'D.UOM_1_CD',
        'D.UOM_2_CD',
        'D.UOM_1_CD_VALUE',
        'D.UOM_2_CD_VALUE',
        'D.CHARGE_RATE',
        'D.CHARGE_AMT',
        'D.PAY_AMT',
        'D.PAY_TAX_AMT',
        'D.CHARGE_TAX_AMT',
        'D.CHARGE_CRNCY_CD',
        'D.EXCHANGE_RATE',
        'D.EXCHANGE_FLG',
        'D.CHARGE_ADJUST_CD',
        'D.GUI_PRINT_FLG',
        'D.CREATE_USER_ID_CD',
        'D.CREATE_TSTAMP',
        'D.LST_UPD_USER_ID_CD',
        'D.LST_UPD_TSTAMP',
        'H.LST_UPD_TSTAMP',
        'H.MANUAL_INVOICE_FLG',
        'D.TAX_PCT',
        'H.LSS_INV_NBR',
        'H.LSS_STATUS_FLG'
      );

    if(type == 'lss_num') {
      query.where('H.LSS_INV_NBR', inv_num);
    }

    if(type == 'invoice_num') {
      query.where('H.INVOICE_NBR', inv_num);
    }

    return query;
  }

  async liLoadLH(inv_num, type) {
    let query = DB.table('A1PRD.LCL_INVC_HEADER')
      .select(
        'INVOICE_NBR',
        'ADM_COUNTRY_CD',
        'GUI_NBR',
        'CR_CLP_SYNC_FLG',
        'SHIPPER_CD',
        'CUST_ACCT_CD',
        'STATUS_CD',
        'INVOICE_DT',
        'VOYAGE_NBR',
        'FEEDER_VOYAGE_NAME',
        'FEEDER_VOYAGE_NBR',
        'MOTHER_VOYAGE_NAME',
        'MOTHER_VOYAGE_NBR',
        'SAILING_DT',
        'INVC_LOAD_PORT_CD',
        'DEST_PORT_CD',
        'WAREHOUSE_CD',
        'TRADE_LANE_CD',
        'FULL_PAYMENT_DT',
        'SHPER_LOAD_PORT_CD',
        'BILL_SHIPPER_CD',
        'SE_SHIPPER_PORT_CD',
        'SE_BILL_SHIPPER_CD',
        'BILL_CUST_ACCT_CD',
        'RRS_ACCOUNT_CD',
        'COMPANY_ID_NBR',
        'BL_SHPER_1_NAME',
        'TAX_ID_NBR',
        'BL_SHPER_2_NAME',
        'BUS_TYPE_TXT',
        'BL_SHPER_3_NAME',
        'SUB_BUS_TYPE_TXT',
        'COMPANY_OWNER_NAME',
        'MANUAL_INVOICE_FLG',
        'BL_SHPER_1_ADDR',
        'PRI_PAY_CRNCY_CD',
        'BL_SHPER_2_ADDR',
        'SCNDY_PAY_CRNCY_CD',
        'BL_SHPER_3_ADDR',
        'EXCHANGE_RATE',
        'POST_RRS_STATUS_CD',
        'VOID_RRS_STATUS_CD',
        'BL_SHPER_4_ADDR',
        'NEW_INVOICE_NBR',
        'BL_SHPER_CITY_NAME',
        'BL_SHPER_STATE_CD',
        'BL_SHPER_CNTRY_CD',
        'BL_SHPER_POSTAL_CD',
        'REMIT_CD',
        'REMIT_NAME',
        'REMIT_1_ADDR',
        'REMIT_2_ADDR',
        'REMIT_3_ADDR',
        'REMIT_4_ADDR',
        'REMIT_CITY_NAME',
        'REMIT_STATE_CD',
        'REMIT_CNTRY_CD',
        'REMIT_POSTAL_CD',
        'PRT_CO_NAME_OFC_CD',
        'CREATE_USER_ID_CD',
        'CREATE_LCL_TSTAMP',
        'LST_UPD_USER_ID_CD',
        'LST_UPD_LCL_TSTAMP',
        'FST_PRT_USER_ID_CD',
        'FST_PRT_LCL_TSTAMP',
        'LST_PRT_USER_ID_CD',
        'LST_PRT_LCL_TSTAMP',
        'VOID_USER_ID_CD',
        'VOID_LOCAL_TSTAMP',
        'VOID_TSTAMP',
        'VOID_REASON_CD',
        'LST_UPD_TSTAMP',
        'GUI_INVOICE_FLG',
        'SHPMT_REQD_FLG',
        'LI_FNL_PRT_RD_FLG',
        'GST_INV_NBR',
        'GST_STS_CD',
        'LSS_INV_NBR',
        'LSS_STATUS_FLG',
        'LSS_STS_CD',
        'D_CHRG_HBL_CNTY_CD',
        'D_CHRG_HBL_NBR',
        'RRS_INTFC_L_TSTAMP',
        'LST_UPD_TSTAMP',
        'LSS_INV_NBR',
        'LSS_STATUS_FLG'
      );

    if(type == 'lss_num') {
      query.where('LSS_INV_NBR', inv_num);
    }

    if(type == 'invoice_num') {
      query.where('INVOICE_NBR', inv_num);
    }

    return query;
  }

  async liLoadLI(inv_num, type) {
    let query = DB.table('A1PRD.LCL_INVC_HEADER as H')
      .leftOuterJoin('A1PRD.LCL_INVC_CHRG_DTL as D', 'H.INVOICE_NBR', 'D.INVOICE_NBR')
      .select(
        'H.INVOICE_NBR',
        'H.ADM_COUNTRY_CD',
        'H.CUST_ACCT_CD',
        'D.CUST_ACCT_CD',
        'H.SHIPPER_CD',
        'D.SHIPPER_CD',
        'H.STATUS_CD',
        'H.INVOICE_DT',
        'H.VOYAGE_NBR',
        'D.VOYAGE_NBR',
        'H.INVC_LOAD_PORT_CD',
        'D.LOAD_PORT_CD',
        'H.DEST_PORT_CD',
        'D.DEST_PORT_CD',
        'H.PRI_PAY_CRNCY_CD',
        'H.RRS_INTFC_L_TSTAMP',
        'D.WAREHOUSE_CD',
        'H.SCNDY_PAY_CRNCY_CD',
        'H.EXCHANGE_RATE',
        'D.SEQUENCE_NBR',
        'D.RATE_METHOD_CD',
        'D.CHARGE_CD',
        'D.CHARGE_DESC_TXT',
        'D.CHARGE_CRNCY_CD',
        'D.UOM_1_CD',
        'D.CHARGE_1_QTY',
        'D.CHARGE_RATE',
        'D.MANUAL_CHARGE_FLG',
        'D.CHARGE_ADJUST_CD',
        'D.CHARGE_AMT',
        'D.CHARGE_TAX_AMT',
        'D.EXCHANGE_RATE',
        'D.EXCHANGE_FLG',
        'D.PAY_AMT',
        'D.PAY_TAX_AMT',
        'D.LST_UPD_USER_ID_CD',
        'D.LST_UPD_TSTAMP',
        'D.SERVICE_TYPE_CD',
        'H.MANUAL_INVOICE_FLG',
        'H.CR_CLP_SYNC_FLG',
        'H.LST_UPD_TSTAMP',
        'H.SHPMT_REQD_FLG',
        'D.TAX_PCT',
        'D.TAX_CD',
        'H.GUI_NBR',
        'H.GST_INV_NBR',
        'H.GST_STS_CD',
        'H.GST_STS_TSTAMP',
        'D.CGST_TAX_PCT',
        'D.UTGST_TAX_PCT',
        'D.SGST_TAX_PCT',
        'D.IGST_TAX_PCT',
        'D.DISCOUNT_PCT',
        'D.CGST_TAX_AMT',
        'D.UTGST_TAX_AMT',
        'D.SGST_TAX_AMT',
        'D.IGST_TAX_AMT',
        'D.DISCOUNT_AMT',
        'H.CR_DR_FLG',
        'H.BL_SHPER_STATE_CD',
        'H.RRS_ACCOUNT_CD',
        'H.REMIT_CD',
        'H.CR_DR_FLG',
        'H.REF_INV_NBR',
        'D.CHARGE_LOC',
        'D.ACTIVITY_IND',
        'H.LSS_INV_NBR',
        'H.LSS_STATUS_FLG'
      );

    if(type == 'lss_num') {
      query.where('H.LSS_INV_NBR', inv_num);
    }

    if(type == 'invoice_num') {
      query.where('H.INVOICE_NBR', inv_num);
    }

    return query;
  }

  async liLoadLR(inv_num, type) {
    let query = DB.table('A1PRD.LCL_INVC_HEADER as A')
      .leftOuterJoin('A1PRD.LCL_INVC_REMARK as B', 'A.INVOICE_NBR', 'B.INVOICE_NBR')
      .select(
        'A.INVOICE_NBR',
        'A.ADM_COUNTRY_CD',
        'A.CR_CLP_SYNC_FLG',
        'A.MANUAL_INVOICE_FLG',
        'A.RRS_INTFC_L_TSTAMP',
        'A.INVOICE_DT',
        'A.STATUS_CD',
        'A.VOYAGE_NBR',
        'A.PRI_PAY_CRNCY_CD',
        'A.LST_UPD_TSTAMP',
        'B.SEQUENCE_NBR',
        'B.REMARK_TXT',
        'B.REMARK_PRINT_FLG',
        'B.SYSTEM_GEND_FLG',
        'B.LST_UPD_USER_ID_CD',
        'B.LST_UPD_TSTAMP',
        'A.LSS_INV_NBR',
        'A.LSS_STATUS_FLG',
        'A.LSS_STS_CD'
      );

    if(type == 'lss_num') {
      query.where('A.LSS_INV_NBR', inv_num);
    }

    if(type == 'invoice_num') {
      query.where('A.INVOICE_NBR', inv_num);
    }

    return query;
  }

  async liLoadTemplates(inv_num, type) {
    let query = DB.table('A1PRD.LSS_INV_TEMPLETES')
      .select(
        'LSS_INV_NBR',
        'SEQ_NBR',
        'INVOICE_NBR',
        'ACS_VOY',
        'CLP_NBR',
        'BOOKING',
        'PO_NBR',
        'STYLE',
        'SUB_STYLE',
        'BL_NBR',
        'CARRIER_CD',
        'HBL_BL_NBR',
        'ADOD',
        'AMOUNT',
        'ASAP',
        'RMK',
        'INCOTERMS',
        'BRAND',
        'CARTON',
        'COLLECT',
        'CONSIGNEE',
        'CNTR_NBR',
        'CTR_SIZE',
        'COST_USD',
        'CPO',
        'CUSTOMER_CODE',
        'DIVISION_NBR',
        'FINAL_DEST',
        'GL_CONSOLIDATION',
        'GL_DEST_DRAYAGE',
        'GL_OCF_AND_ACC',
        'HBL_NBR',
        'INT_PO',
        'LIN',
        'MGFEE',
        'PKGS',
        'UOM',
        'PLANT_CODE',
        'REF_NBR',
        'SHIP_TO',
        'SHIPMENT_BL_NBR',
        'SHIPMENT_NBR',
        'SHIPPER_NAME',
        'SWY_PO_NO',
        'CBM',
        'ROUTE',
        'KGS',
        'WHC',
        'LI_BL',
        'LI_SO',
        'LI_EXCHANGE_RATE',
        'LI_CNTR_NBR',
        'LI_HBL_NBR',
        'LI_FCR_NBR',
        'CREATE_USER_ID_CD',
        'CREATE_TSTAMP',
        'LST_UPD_USER_ID_CD',
        'LST_UPD_TSTAMP'
      )
      .whereNotNull('LSS_INV_NBR');

    if(type == 'lss_num') {
      query.where('LSS_INV_NBR', inv_num).where('SEQ_NBR', '>=', 0);
    }

    if(type == 'invoice_num') {
      query.where('INVOICE_NBR', inv_num).where('SEQ_NBR', '>=', 0);
    }

    query.orderBy('LSS_INV_NBR').orderBy('INVOICE_NBR').orderBy('SEQ_NBR');

    return query;
  }

  async advanceSearch(params) {
    let query = DB.table('A1PRD.INVOICE_HDR')
                  .select(
                    'INVOICE_NBR',
                    'LSS_INV_NBR',
                    'ACS_CUST_ACCT_CD',
                    'ORIG_PORT_CD',
                    'DEST_PORT_CD',
                    'BILLING_CD',
                    'REMIT_CD',
                    'INVOICE_DT'
                  )

    let utility = new Utility();
                    console.log(params);
    let cust_acct_cd = params['cust_acct_cd'];
    let origin_port = utility.fillOriginPortCode(params['origin_port']);
    let dest_port = utility.fillDestPortCode(params['dest_port']);
    let billing_cd = utility.fillBillingCd(params['billing_cd']);
    let remit_cd = params['remit_cd'];
    let invoice_dt_from = params['invoice_dt_from'];
    let invoice_dt_to = params['invoice_dt_to'] ? params['invoice_dt_to'] : '';

    if(cust_acct_cd.trim()) {
      query.where('ACS_CUST_ACCT_CD', cust_acct_cd.toUpperCase());
    }
    if(origin_port.trim()) {
      console.log(origin_port.length)
      query.where('ORIG_PORT_CD', origin_port.toUpperCase());
    }
    if(dest_port.trim()) {
      query.where('DEST_PORT_CD', dest_port.toUpperCase());
    }
    if(billing_cd.trim()) {
      query.where('BILLING_CD', billing_cd.toUpperCase());
    }
    if(remit_cd.trim()) {
      query.where('REMIT_CD', remit_cd.toUpperCase());
    }
    if(invoice_dt_from.trim()) {
      console.log('tfrom ',invoice_dt_from)
      console.log(typeof invoice_dt_from, invoice_dt_to.length)
      query.where('INVOICE_DT', '>', invoice_dt_from);
    }
    if(invoice_dt_to.trim()) {
      console.log('to ',invoice_dt_to)
      console.log(typeof invoice_dt_to, invoice_dt_to.length)
      query.where('INVOICE_DT', '<', invoice_dt_to);
    }
    query.groupBy('INVOICE_NBR',
      'ACS_CUST_ACCT_CD',
      'LSS_INV_NBR',
      'ORIG_PORT_CD',
      'DEST_PORT_CD',
      'BILLING_CD',
      'REMIT_CD',
      'INVOICE_DT')
    query.orderBy('INVOICE_DT', 'DESC').limit(30)

    return query;
  }

}

module.exports = InvoiceDisplay
