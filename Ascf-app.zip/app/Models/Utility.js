'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Utility extends Model {

  fillSpaces(user_string, length) {
    if(user_string.length < length) {
      var addSpaces = length - user_string.length;
      for(var i = 0; i < addSpaces; i++) {
        user_string += ' ';
      }
    }
    return user_string;
  }

  fillLssInvNumber(user_string) {
    if(user_string.length < 20) {
      var addSpaces = 20 - user_string.length;
      for(var i = 0; i < addSpaces; i++) {
        user_string += ' ';
      }
    }
    return user_string;
  }

  fillOriginPortCode(user_string) {
    if(user_string.length < 6) {
      var addSpaces = 6 - user_string.length;
      for(var i = 0; i < addSpaces; i++) {
        user_string += ' ';
      }
    }
    return user_string;
  }

  fillDestPortCode(user_string) {
    if(user_string.length < 6) {
      var addSpaces = 6 - user_string.length;
      for(var i = 0; i < addSpaces; i++) {
        user_string += ' ';
      }
    }
    return user_string;
  }

  fillBillingCd(user_string) {
    if(user_string.length < 6) {
      var addSpaces = 6 - user_string.length;
      for(var i = 0; i < addSpaces; i++) {
        user_string += ' ';
      }
    }
    return user_string;
  }

}

module.exports = Utility
