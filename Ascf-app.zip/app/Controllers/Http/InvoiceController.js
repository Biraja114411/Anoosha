const iPrint = use('App/Models/InvoicePrint')
const iDisplay = use('App/Models/InvoiceDisplay')
const Utility = use('App/Models/Utility')

class InvoiceController {

  home({view}) {
    return view.render('home');
  }

  async getUser({request, response}) {
    const Inv = new iPrint();
    let user = await Inv.getUser();
    response.json({
      user: user
    })
  }

  async confirmPrint({request, response}) {
    // TODO: set locks based on user profile
    let params = request.get();
    const data = JSON.parse(params['data']);

    let iData = data['data'];
    let iConfig = data['config'];
    let user = data['user'];

    console.log(iData)
    console.log(iConfig)
    console.log(user)

    const Inv = new iPrint();

    // printer validation
    let vld = await Inv.printerValidation(iConfig);

    if(vld.length == 0) {
      return {
        status: false,
        message: 'Invalid Printer'
      }
    }

    // Get new request number
    const old_req_num = await Inv.getOldReqNum();
    console.log('old ',old_req_num)

    let new_req_num = '001';
    if(old_req_num) {
      let new_req_temp = (parseInt(old_req_num) + 1).toString();
      new_req_num = new_req_temp.length == 2 ? '0'+new_req_temp : '00'+new_req_temp;
    }

    // Get new request number
    let new_db_key = await Inv.getOldDBKey();
    new_db_key = new_db_key[0].NEXTVAL;


    // Insert new request number into request rec table
    const insert_rec = await Inv.insertRec(iData, iConfig, user, new_req_num, new_db_key)

    // Get new order number
    const old_order_num = await Inv.getOldOrderNum(iData);
    let new_order_num = parseInt(old_order_num) + 1;
    // let new_order_num = '00000001';
    if(old_order_num) {
      let new_order_num = (parseInt(old_order_num) + 1).toString();
      for(let i = 0; i < (8- old_order_num.length); i++) {
        new_order_num = '0' + old_order_num;
      }
    }

    // Insert new order number into IDMSDB.REPT_RQST_SET
    const insert_rqst_set = await Inv.insertRqstSet(new_req_num, new_order_num);

    // Get new rqcr number
    let new_rqcr_db_key = await Inv.getOldRqcrDBKey();
    new_rqcr_db_key = new_rqcr_db_key[0].NEXTVAL;

    // Create 15 RQCR REC
    const create_rqcr = await Inv.createRqcr(iData, iConfig, new_req_num, new_rqcr_db_key)

    // Create JCL
    const create_jcl = await Inv.createJCL(new_req_num)

    response.json({
      "req_num": new_req_num,
      "db_key": new_db_key,
      'insert_rec': insert_rec,
      'order_num': new_order_num,
      'insert_rqst_set': insert_rqst_set,
      'rqcr': create_rqcr,
      'jcl': create_jcl
    })
  }

  async fetchOI({request, response}) {

    const params = request.get();
    let invoice_number = params['inv_number'];
    let so_number = params['so_number'];
    let gst_number = params['gst_number'];

    let utility = new Utility();
    so_number = utility.fillLssInvNumber(params['so_number']);
    gst_number = utility.fillLssInvNumber(params['gst_number']);

    try {
      const Inv = new iDisplay();
      const ih = await Inv.oiLoadIH(invoice_number, so_number, gst_number)
      const ig = await Inv.oiLoadIG(invoice_number, so_number, gst_number)
      const id = await Inv.oiLoadID(invoice_number, so_number, gst_number)
      const im = await Inv.oiLoadIM(invoice_number, so_number, gst_number)
      const ir = await Inv.oiLoadIR(invoice_number, so_number, gst_number)
      const template = await Inv.oiLoadTemplates(invoice_number, so_number, gst_number);
      const admin_cty = await Inv.getAdminCountry(ih[0].ORIG_PORT_CD);

      response.json(
        {
          success: true,
          data: {
            ih: ih,
            ig: ig,
            id: id,
            im: im,
            ir: ir,
            template: template,
            admin_cty: admin_cty
          }
        }
      )
    } catch(error) {
      response.json(
        {
          success: false,
          error: error.message
        }
      )
    }
  }

  async fetchLI({request, response}) {

    const params = request.get();
    let invoice_number;
    let inv_type;

    if(typeof params['inv_num'] == 'undefined') {
      if(typeof params['lss_num'] == 'undefined') {
        response.json(
          {
            success: false,
            error: 'Invoice number is required'
          }
        )
      } else {
        let utility = new Utility();
        invoice_number = utility.fillLssInvNumber(params['lss_num']);
        inv_type = 'lss_num';
      }
    } else {
      invoice_number = params['inv_num'];
      inv_type = 'invoice_num';
    }

    try {
      const Inv = new iDisplay();
      const lc = await Inv.liLoadLC(invoice_number, inv_type);
      const ld = await Inv.liLoadLD(invoice_number, inv_type);
      const lh = await Inv.liLoadLH(invoice_number, inv_type);
      const li = await Inv.liLoadLI(invoice_number, inv_type);
      const lr = await Inv.liLoadLR(invoice_number, inv_type);
      const template = await Inv.liLoadTemplates(invoice_number, inv_type);

      response.json(
        {
          success: true,
          data: {
            lc: lc,
            ld: ld,
            lh: lh,
            li: li,
            lr: lr,
            template: template
          }
        }
      )
    } catch(error) {
      response.json(
        {
          success: false,
          error: error.message
        }
      )
    }
  }

  async displayAdvanceSearch({request, response}) {
    const params = request.get()
    console.log(params)
    const Inv = new iDisplay();
    let searchResult = await Inv.advanceSearch(params)
    console.log('done')
    response.json({
      data: searchResult
    })
  }

  async validateInvoice({request, response}) {
    const params = request.get();

    const Inv = new iPrint();
    let result = await Inv.validateInvoice(params);
    response.json({
      data: result
    })
  }

}

module.exports = InvoiceController
