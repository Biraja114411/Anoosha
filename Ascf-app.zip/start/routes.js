'use strict'

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/

/** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use('Route')

Route.get('', 'InvoiceController.home')

Route.group(() => {
  Route.get('auth', 'InvoiceController.auth')
  Route.get('user', 'InvoiceController.getUser')
  Route.get('invoice/fetch/oi', 'InvoiceController.fetchOI')
  Route.get('invoice/fetch/li', 'InvoiceController.fetchLI')
  Route.get('invoice/search/oi', 'InvoiceController.displayAdvanceSearch')

  Route.get('invoice/validate/oi', 'InvoiceController.validateInvoice')
  Route.get('invoice/print/oi', 'InvoiceController.confirmPrint')
}).prefix('api/v1')
