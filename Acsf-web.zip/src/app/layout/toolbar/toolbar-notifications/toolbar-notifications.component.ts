import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { LIST_FADE_ANIMATION } from '../../../../@acsf/shared/list.animation';

@Component({
  selector: 'acsf-toolbar-notifications',
  templateUrl: './toolbar-notifications.component.html',
  styleUrls: ['./toolbar-notifications.component.scss'],
  animations: [...LIST_FADE_ANIMATION],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ToolbarNotificationsComponent implements OnInit {

  notifications: any[];
  isOpen: boolean;

  constructor() {
  }

  ngOnInit() {
    this.notifications = [
      {
        icon: 'notifications',
        name: 'Print Job# PR1142 has been processed',
        time: 'few sec ago',
        read: false,
        colorClass: 'primary'
      },
      {
        icon: 'notifications',
        name: 'Print job JOB# PR1142 has been submitted',
        time: '6 min ago',
        read: true,
        colorClass: 'primary'
      }
    ];
  }

  markAsRead(notification) {
    notification.read = true;
  }

  dismiss(notification, event) {
    event.stopPropagation();
    this.notifications.splice(this.notifications.indexOf(notification), 1);
  }

  toggleDropdown() {
    this.isOpen = !this.isOpen;
  }

  onClickOutside() {
    this.isOpen = false;
  }

  markAllAsRead() {
    this.notifications.forEach(notification => notification.read = true);
  }
}
