import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';
import { BusinessPartnerComponent } from './master/business-partner/business-partner.component';
import { CustomsComponent } from './customs/customs.component';
import { RoleComponent } from './master/role/role.component';
import {InvoiceDisplayComponent} from './invoice/invoice-display/invoice-display.component';
import {InvoicePrintComponent} from './invoice/invoice-print/invoice-print.component';
import {TableComponent} from './customs/table/table.component';

const routes: Routes = [
  {
    path: 'login',
    loadChildren: './authentication/login/login.module#LoginModule',
  },
  {
    path: 'register',
    loadChildren: './authentication/register/register.module#RegisterModule',
  },
  {
    path: 'forgot-password',
    loadChildren: './authentication/forgot-password/forgot-password.module#ForgotPasswordModule',
  },
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: '',
        component: BusinessPartnerComponent,
        pathMatch: 'full'
      },
      {
        path: 'master/business-partners',
        component: BusinessPartnerComponent,
        pathMatch: 'full'
      },
      {
        path: 'master/user-role',
        component: RoleComponent,
        pathMatch: 'full'
      },
      {
        path: 'customs',
        component: CustomsComponent,
        pathMatch: 'full'
      },
      {
        path: 'invoice/invoice-display',
        component: InvoiceDisplayComponent,
        pathMatch: 'full'
      },
      {
        path: 'invoice/invoice-print',
        component: InvoicePrintComponent,
        pathMatch: 'full'
      },
      {
        path: 'customs/table',
        component: TableComponent,
        pathMatch: 'full'
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    initialNavigation: 'enabled',
    // preloadingStrategy: PreloadAllModules,
    scrollPositionRestoration: 'enabled',
    anchorScrolling: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
