import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { fadeInUpStaggerAnimation } from '../../../@acsf/animations/fade-in-up.animation';
import { fadeInRightAnimation } from '../../../@acsf/animations/fade-in-right.animation';

@Component({
  selector: 'acsf-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.scss'],
  animations: [fadeInUpStaggerAnimation, fadeInRightAnimation]
})
export class RoleComponent implements OnInit {
  roleFormGroup: FormGroup;
  private _gap = 16;
  gap = `${this._gap}px`;
  col1 = `1 calc(80% - ${this._gap / 2}px)`;
  col2 = `1 1 calc(61% - ${this._gap / 1.5}px)`;
  col3 = `1 1 calc(33.3333% - ${this._gap / 1.5}px)`;
  col4 = `1 1 calc(23% - ${this._gap / 1.5}px)`;
  col5 = `1 1 calc(120px - ${this._gap / 1.5}px)`;

  constructor(private fb: FormBuilder) {  }

  ngOnInit() {
    this.roleFormGroup = this.fb.group({
      role_id: [null, Validators.required],
      header_level: [null, Validators.required],
      txn_level: [null, Validators.required],
      roles: [null, Validators.required],
    });
  }

}
