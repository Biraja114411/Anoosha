import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {fadeInUpStaggerAnimation} from '../../../@acsf/animations/fade-in-up.animation';
import {fadeInRightAnimation} from '../../../@acsf/animations/fade-in-right.animation';

@Component({
    selector: 'acsf-business-partner',
    templateUrl: './business-partner.component.html',
    styleUrls: ['./business-partner.component.scss'],
    animations: [fadeInUpStaggerAnimation, fadeInRightAnimation]
})
export class BusinessPartnerComponent implements OnInit {
    bizPartnerFormGroup: FormGroup;
    private _gap = 16;
    gap = `${this._gap}px`;
    col2 = `1 calc(70% - ${this._gap / 2}px)`;
    col3 = `1 1 calc(33.3333% - ${this._gap / 1.5}px)`;

    constructor(private fb: FormBuilder) {
    }

    ngOnInit() {
        this.bizPartnerFormGroup = this.fb.group({
            biz_partner_cd: [null, Validators.required],
            biz_partner_type: [null, Validators.required],
            biz_partner_name: [null, Validators.required],
            mas_customer_cd: [null, Validators.required],
            mas_customer_name: [null, Validators.required],
            bt_cd: [null, Validators.required],
            sales_city: [null, Validators.required],
            sales_person: [null, Validators.required],
            la: [null, Validators.required],
            bus_id: [null, Validators.required],
            biz_email: [null, Validators.required],
            bus_sub_type: [null, Validators.required],
            vat_id: [null, Validators.required],
            gst_in: [null, Validators.required],
            fin_acct_cd: [null, Validators.required],
            sap_cust_nbr: [null, Validators.required],
            rrs_ext_flg: [null, Validators.required],
            fst_rrs_ext: [null, Validators.required],
            last_rrs_ext: [null, Validators.required],
            addr_1: [null, Validators.required],
            addr_2: [null, Validators.required],
            addr_3: [null, Validators.required],
            addr_4: [null, Validators.required],
            biz_state: [null, Validators.required],
            biz_city: [null, Validators.required],
            biz_country: [null, Validators.required],
            biz_postal: [null, Validators.required],
            biz_contact1: [null, Validators.required],
            biz_contact2: [null, Validators.required],
            biz_phoneno: [null, Validators.required],
            biz_fax: [null, Validators.required],
            biz_faxbiz_email: [null, Validators.required],
            inv_delivery: [null, Validators.required],
            inv_frequency: [null, Validators.required],
            inv_cr_allow: [null, Validators.required],
            edi_inv_rsnd: [null, Validators.required],
        });
    }
}
