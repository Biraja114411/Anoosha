import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'acsf-constants',
  templateUrl: './constants.component.html',
  styleUrls: ['./constants.component.scss']
})
export class ConstantsComponent implements OnInit {

  private _gap = 16;
  public gap = `${this._gap}px`;
  public col1 = `1 calc(80% - ${this._gap / 2}px)`;
  public col2 = `1 1 calc(61% - ${this._gap / 1.5}px)`;
  public col3 = `1 1 calc(33.3333% - ${this._gap / 1.5}px)`;
  public col4 = `1 1 calc(23% - ${this._gap / 1.5}px)`;
  public col5 = `1 1 calc(120px - ${this._gap / 1.5}px)`;

  constructor() { }

  ngOnInit() {
  }

}
