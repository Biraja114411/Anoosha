import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BusinessPartnerComponent } from './master/business-partner/business-partner.component';

import 'hammerjs'; // Needed for Touch functionality of Material Components
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutModule } from './layout/layout.module';
import { AgmCoreModule } from '@agm/core';
import { environment } from '../environments/environment';
import { PendingInterceptorModule } from '../@acsf/shared/loading-indicator/pending-interceptor.module';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldDefaultOptions } from '@angular/material/form-field';
import { MAT_SNACK_BAR_DEFAULT_OPTIONS, MatSnackBarConfig } from '@angular/material/snack-bar';
import {AcsfSharedModule} from '../@acsf/acsf-shared.module';
import {AcsfCardModule} from '../@acsf/shared/card/card.module';
import {MaterialModule} from '../@acsf/shared/material-components.module';
import { CustomsComponent, DemoDialogComponent } from './customs/customs.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { RoleComponent } from './master/role/role.component';
import { InvoiceDisplayComponent } from './invoice/invoice-display/invoice-display.component';
import {ListModule} from '../@acsf/shared/list/list.module';
import { InvoicePrintComponent } from './invoice/invoice-print/invoice-print.component';
import { PrintOptionComponent } from './invoice/invoice-print/invoice-print.component';
import { PrintAdvancedSearchComponent } from './invoice/invoice-print/print-advanced-search/print-advanced-search.component';
import { ConstantsComponent } from './constants/constants.component';
import { DisplayAdvancedSearchComponent } from './invoice/invoice-display/display-advanced-search/display-advanced-search.component';
import { TagInputModule } from 'ngx-chips';
import { TableComponent } from './customs/table/table.component';

import { InvDisplayRemarksComponent } from './invoice/invoice-display/inv-display-remarks/inv-display-remarks.component';
import { InvDisplayTemplateComponent } from './invoice/invoice-display/inv-display-template/inv-display-template.component';
@NgModule({
    imports: [
        // Angular Core Module // Don't remove!
        BrowserModule,
        BrowserAnimationsModule,
        HttpClientModule,

        // Acsf Core Modules
        AppRoutingModule,

        // Layout Module (Sidenav, Toolbar, Quickpanel, Content)
        LayoutModule,

        // Google Maps Module
        AgmCoreModule.forRoot({
            apiKey: environment.googleMapsApiKey
        }),

        // Displays Loading Bar when a Route Request or HTTP Request is pending
        PendingInterceptorModule,
        AcsfSharedModule,
        AcsfCardModule,
        MaterialModule,
        ReactiveFormsModule,
        ListModule,
        FormsModule,
        TagInputModule
        // Register a Service Worker (optional)
        // ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
    ],
  declarations: [AppComponent, BusinessPartnerComponent, CustomsComponent, DemoDialogComponent, RoleComponent, InvoiceDisplayComponent, InvoicePrintComponent, PrintOptionComponent, PrintAdvancedSearchComponent, ConstantsComponent, DisplayAdvancedSearchComponent, TableComponent, InvDisplayRemarksComponent, InvDisplayTemplateComponent],
  bootstrap: [AppComponent],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: {
        appearance: 'fill'
      } as MatFormFieldDefaultOptions
    },
    {
      provide: MAT_SNACK_BAR_DEFAULT_OPTIONS,
      useValue: {
        duration: 5000,
        horizontalPosition: 'end',
        verticalPosition: 'bottom'
      } as MatSnackBarConfig
    }
  ],
  entryComponents: [
    DemoDialogComponent,
    PrintAdvancedSearchComponent,
    PrintOptionComponent,
    DisplayAdvancedSearchComponent,
    InvDisplayRemarksComponent,
    InvDisplayTemplateComponent
  ]
})
export class AppModule {
}
