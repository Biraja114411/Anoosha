import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {FormGroup} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatDialog, MatDialogRef} from '@angular/material';
import {fadeInUpStaggerAnimation} from '../../@acsf/animations/fade-in-up.animation';
import {fadeInRightAnimation} from '../../@acsf/animations/fade-in-right.animation';

@Component({
  selector: 'acsf-customs',
  templateUrl: './customs.component.html',
  styleUrls: ['./customs.component.scss'],
  animations: [fadeInUpStaggerAnimation, fadeInRightAnimation]
})
export class CustomsComponent implements OnInit {
  CustomFormGroup: FormGroup;
  visible = false;
  inputType = 'password';
  private _gap = 16;
  gap = `${this._gap}px`;
  col1 = `1 calc(80% - ${this._gap / 2}px)`;
  col2 = `1 1 calc(50% - ${this._gap / 1.5}px)`;
  col3 = `1 1 calc(33.3333% - ${this._gap / 1.5}px)`;
  col4 = `1 1 calc(23% - ${this._gap / 1.5}px)`;

  result: string;
  formCheckboxSource: any;
  showFormCheckboxSource: any;
  formRadioSource: any;
  showFormRadioSource: any;
  formSliderSource: any;
  showFormSliderSource: any;

  constructor(  private snackBar: MatSnackBar, private cd: ChangeDetectorRef, private dialog: MatDialog) { }

  ngOnInit() {
  }

  openSnackbar() {
    this.snackBar.open('I\'m a notification!', 'CLOSE', {
      duration: 3000,
      horizontalPosition: 'right'
    });
  }

  togglePassword() {
    if (this.visible) {
      this.inputType = 'password';
      this.visible = false;
      this.cd.markForCheck();
    } else {
      this.inputType = 'text';
      this.visible = true;
      this.cd.markForCheck();
    }
  }
  openDialog() {
    this.dialog.open(DemoDialogComponent, {
      disableClose: false
    }).afterClosed().subscribe(result => {
      this.result = result;
    });
  }

}

@Component({
  selector: 'acsf-demo-dialog',
  template: `
    <div mat-dialog-title fxLayout="row" fxLayoutAlign="space-between center">
      <div>Question</div>
      <button type="button" mat-icon-button (click)="close('No answer')" tabindex="-1">
        <mat-icon>close</mat-icon>
      </button>
    </div>

    <mat-dialog-content>
      <p>Do you like Pizza?</p>
    </mat-dialog-content>


    <mat-dialog-actions align="end">
      <button mat-button (click)="close('No')">No</button>
      <button mat-button color="primary" (click)="close('Yes')">Yes</button>
  </mat-dialog-actions>
  `
})

export class DemoDialogComponent {
  constructor(private dialogRef: MatDialogRef<DemoDialogComponent>) {
  }

  close(answer: string) {
    this.dialogRef.close(answer);
  }
}
