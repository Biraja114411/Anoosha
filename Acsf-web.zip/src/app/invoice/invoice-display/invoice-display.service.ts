import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})

export class InvoiceDisplayService {
  private oi_get_url = 'http://127.0.0.1:3333/api/v1/invoice/fetch/oi';
  private advance_search_url = 'http://127.0.0.1:3333/api/v1/invoice/search/oi';
  constructor(private http: HttpClient) {
  }

  public getOi(data) {
    return this.http.get(this.oi_get_url, { withCredentials: true, params: data });
  }

  public getAdvanceSearch(data) {
    const datePipe = new DatePipe('en-US');
    data.invoice_dt_from = data.invoice_dt_from ? datePipe.transform(data.invoice_dt_from, 'dd-MMM-yyyy').toString() : '';
    if (data.invoice_dt_from) {
      const frmDt: any = new Date(data.invoice_dt_from)
      data.invoice_dt_from = datePipe.transform(frmDt.setDate(frmDt.getDate() - 1), 'dd-MMM-yyyy');
      console.log(data.invoice_dt_from);
    }

    data.invoice_dt_to = data.invoice_dt_to ? datePipe.transform(data.invoice_dt_to, 'dd-MMM-yyyy') : '';
    if (data.invoice_dt_to) {
      const toDt: any = new Date(data.invoice_dt_to)
      data.invoice_dt_to = datePipe.transform(toDt.setDate(toDt.getDate() + 1), 'dd-MMM-yyyy');
      console.log(data.invoice_dt_to)
    }

    console.log(data);
    return this.http.get(this.advance_search_url, { withCredentials: true, params: data });
  }
}
