export const ALL_IN_ONE_TABLE_DEMO_DATA = [
  {
    'INVOICE_NBR': 0,
    'ACS_CUST_ACCT_CD': 'MAAN073429',
  },
  {
    'INVOICE_NBR': 1,
    'ACS_CUST_ACCT_CD': 'ABCD123456',
  }
];
