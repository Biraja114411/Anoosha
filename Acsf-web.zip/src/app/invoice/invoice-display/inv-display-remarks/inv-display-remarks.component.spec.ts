import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvDisplayRemarksComponent } from './inv-display-remarks.component';

describe('InvDisplayRemarksComponent', () => {
  let component: InvDisplayRemarksComponent;
  let fixture: ComponentFixture<InvDisplayRemarksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvDisplayRemarksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvDisplayRemarksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
