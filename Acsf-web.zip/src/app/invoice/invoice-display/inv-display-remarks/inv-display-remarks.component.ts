import {Component, Inject, OnInit} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'acsf-inv-display-remarks',
  templateUrl: './inv-display-remarks.component.html',
  styleUrls: ['./inv-display-remarks.component.scss']
})
export class InvDisplayRemarksComponent implements OnInit {

  ir: any = [];
  displayedColumns: string[] = ['SEQ_NBR', 'REMARKS', 'SYS_GEN_FLG', 'PRINT_FLG'];
  dataSource = [];
  constructor(private dialogRef: MatDialogRef<any>, @Inject(MAT_DIALOG_DATA) public invoiceData: any) {}

  ngOnInit() {
    console.log(this.invoiceData);
    console.log(this.invoiceData.resultSet.ir)
    let data = this.invoiceData.resultSet.ir;
    data = data.map((e) => {
      return {
        SEQ_NBR: e.SEQ_NBR,
        REMARKS: e.REMARKS,
        SYS_GEN_FLG: e.SYS_GEN_FLG,
        PRINT_FLG: e.PRINT_FLG
      };
    });
    console.log(data)
    this.dataSource = data;
  }

  close() {
    this.dialogRef.close();
  }

}
