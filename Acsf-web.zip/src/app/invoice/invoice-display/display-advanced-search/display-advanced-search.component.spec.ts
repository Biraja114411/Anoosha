import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayAdvancedSearchComponent } from './display-advanced-search.component';

describe('DisplayAdvancedSearchComponent', () => {
  let component: DisplayAdvancedSearchComponent;
  let fixture: ComponentFixture<DisplayAdvancedSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayAdvancedSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayAdvancedSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
