import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {MatTableDataSource} from '@angular/material/table';
import {InvoiceDisplayService} from '../invoice-display.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import Swal from "sweetalert2";

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

/**
 * @title Table with selection
 */
@Component({
  selector: 'acsf-display-advanced-search',
  templateUrl: './display-advanced-search.component.html',
  styleUrls: ['./display-advanced-search.component.scss']
})
export class DisplayAdvancedSearchComponent implements OnInit {
  advanceSearchForm: FormGroup;

  private _gap = 16;
  gap = `${this._gap}px`;
  col1 = `1 calc(80% - ${this._gap / 2}px)`;
  private advSearchBtnDisabled = false;

  constructor(private dialogRef: MatDialogRef<DisplayAdvancedSearchComponent>, private ds: InvoiceDisplayService, private fb: FormBuilder) {
  }

  ngOnInit() {
    this.advanceSearchForm = this.fb.group({
      'cust_acct_cd': '',
      'remit_cd': '',
      'origin_port': '',
      'dest_port': '',
      'billing_cd': '',
      'invoice_dt_to': '',
      'invoice_dt_from': ''
    });
  }

  close(data) {
    this.dialogRef.close(data);
  }

  advanceSearch() {
    let formDataSet = Object.values(this.advanceSearchForm.value);
    formDataSet = formDataSet.filter((e) => {
      return e && e.toString().trim().length;
    });
    if (!formDataSet.length) {
      Swal.fire('', 'That was an invalid search', 'warning');
      this.advSearchBtnDisabled = false;
      return false;
    }
    this.ds.getAdvanceSearch(this.advanceSearchForm.value).subscribe((res: any) => {
      if (!res.data.length) {
        Swal.fire('', 'Nothing found matching your search criteria.', 'warning');
        return false;
      }
      this.dialogRef.close(res.data);
    }, (e) => {
      console.log(e);
      Swal.fire('', 'Server error. Contact Administrator.', 'error');
    });
  }
}
