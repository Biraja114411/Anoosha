import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Observable, of, ReplaySubject } from 'rxjs';
import { ListColumn } from '../../../@acsf/shared/list/list-column.model';
import { fadeInRightAnimation } from '../../../@acsf/animations/fade-in-right.animation';
import { fadeInUpStaggerAnimation } from '../../../@acsf/animations/fade-in-up.animation';
import { fadeInUpAnimation } from '../../../@acsf/animations/fade-in-up.animation';
import { InvoiceDisplayService } from './invoice-display.service';
import { DisplayAdvancedSearchComponent } from './display-advanced-search/display-advanced-search.component';
import { InvDisplayRemarksComponent } from './inv-display-remarks/inv-display-remarks.component';
import { InvDisplayTemplateComponent } from './inv-display-template/inv-display-template.component';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'acsf-invoice-display',
  templateUrl: './invoice-display.component.html',
  styleUrls: ['./invoice-display.component.scss'],
  animations: [fadeInRightAnimation, fadeInUpAnimation, fadeInUpStaggerAnimation]
})
export class InvoiceDisplayComponent implements OnInit {
  private _gap = 16;
  gap = `${this._gap}px`;
  col1 = `1 calc(80% - ${this._gap / 2}px)`;
  col2 = `1 1 calc(50% - ${this._gap / 1.5}px)`;
  col3 = `1 1 calc(33.3333% - ${this._gap / 1.5}px)`;
  col4 = `1 1 calc(23% - ${this._gap / 1.5}px)`;
  col5 = `1 1 calc(120px - ${this._gap / 1.5}px)`;
  /**
   * Simulating a service with HTTP that returns Observables
   * You probably want to remove this and do all requests in a service with HTTP
   */
  result: string;
  disableSearchBtn = false;

  invoiceSearchResults: Observable<Array<any>>;
  showInvoiceSearchResults = false;
  showInvoiceAdvanceSearchResults = false;
  showSearchForm = true;
  searchForm: FormGroup;
  gstEnabled = false;

  @Input()
  columns: ListColumn[] = [
    { name: 'LN', property: 'SEQ_NBR', visible: true, isModelProperty: true },
    { name: 'CODE', property: 'CHARGE_CD', visible: true, isModelProperty: true },
    { name: 'DESC', property: 'CHARGE_DESC', visible: true, isModelProperty: true },
    { name: 'SVC', property: 'SERVICE_TYPE_CD', visible: true, isModelProperty: true },
    { name: 'CCY', property: 'CURRENCY_CD', visible: true, isModelProperty: true },
    { name: 'UNIT', property: 'UNIT_CD_1', visible: true, isModelProperty: true },
    { name: 'QTY', property: 'QUANTITY_1', visible: true, isModelProperty: true },
    { name: 'RATE', property: 'RATE', visible: true, isModelProperty: true },
    { name: 'AMOUNT', property: 'AMOUNT_1', visible: true, isModelProperty: true },
    { name: 'EXCH RATE', property: 'EXCHANGE_RATE', visible: true, isModelProperty: true },
    { name: 'TAX CODE', property: 'GSTR1TC', visible: true, isModelProperty: true },
    { name: 'TAX %', property: 'GSTR1TP', visible: true, isModelProperty: true },
    { name: 'TAX AMT', property: 'GSTR1TA', visible: true, isModelProperty: true },
    { name: 'TAX CODE', property: 'GSTR2TC', visible: true, isModelProperty: true },
    { name: 'TAX %', property: 'GSTR2TP', visible: true, isModelProperty: true },
    { name: 'TAX AMT', property: 'GSTR2TA', visible: true, isModelProperty: true },
    { name: 'TAX CODE', property: 'GSTR3TC', visible: true, isModelProperty: true },
    { name: 'TAX %', property: 'GSTR3TP', visible: true, isModelProperty: true },
    { name: 'TAX AMT', property: 'GSTR3TA', visible: true, isModelProperty: true },
    { name: 'TAX CODE', property: 'GSTR4TC', visible: true, isModelProperty: true },
    { name: 'TAX %', property: 'GSTR4TP', visible: true, isModelProperty: true },
    { name: 'TAX AMT', property: 'GSTR4TA', visible: true, isModelProperty: true },
    { name: 'PAY AMOUNT', property: 'PAY_AMOUNT', visible: true, isModelProperty: true },
    { name: 'M', property: 'MAN_CHRG_FLG', visible: true, isModelProperty: true },
    { name: 'REFERENCE', property: 'INVC_CHRG_REF_NBR', visible: true, isModelProperty: true },
    { name: 'VAT', property: 'VAT_ID_NBR', visible: true, isModelProperty: true },
    { name: 'RSN', property: 'RSN', visible: true, isModelProperty: true },
  ] as ListColumn[];
  advanceColumns: ListColumn[] = [
    { name: 'INV#', property: 'INVOICE_NBR', visible: true, isModelProperty: true, isLink: true, callBack: this.searchFromInvoiceLink, scope: this },
    { name: 'SO#', property: 'LSS_INV_NBR', visible: true, isModelProperty: true, isLink: true, callBack: this.searchFromSOLink, scope: this },
    { name: 'CUSTOMER', property: 'ACS_CUST_ACCT_CD', visible: true, isModelProperty: true, isText: true },
    { name: 'BILLER', property: 'BILLING_CD', visible: true, isModelProperty: true, isText: true },
    { name: 'ORIGIN', property: 'ORIG_PORT_CD', visible: true, isModelProperty: true, isText: true },
    { name: 'DESTINATION', property: 'DEST_PORT_CD', visible: true, isModelProperty: true, isText: true },
    { name: 'SAIL DT', property: 'INVOICE_DT', visible: true, isModelProperty: true, isDate: true, format: 'dd-MMM-yyyy hh:mm' },
    { name: 'REMIT CD', property: 'REMIT_CD', visible: true, isModelProperty: true, isText: true }
    
  ] as ListColumn[];
  pageSize = 10;
  advancePageSize = 10;
  dataSource: MatTableDataSource<any> | null;
  advanceDataSource: MatTableDataSource<any> | null;

  hdrInvAmt: any = {};

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(private snackBar: MatSnackBar, private dialog: MatDialog, private is: InvoiceDisplayService, private fb: FormBuilder) {
  }

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  get advanceVisibleColumns() {
    return this.advanceColumns.filter(column => column.visible).map(column => column.property);
  }

  ngOnInit() {
    this.searchForm = this.fb.group({
      'inv_number': '',
      'so_number': '',
      'gst_number': ''
    });
    this.searchForm.patchValue({
      inv_number: 'MAAN073429'
    });

    this.dataSource = new MatTableDataSource();
    this.advanceDataSource = new MatTableDataSource();
  }

  openInvoiceDisplayDialog() {
    this.dialog.open(DisplayAdvancedSearchComponent, {
      disableClose: false
    }).afterClosed().subscribe((result) => {
      this.result = result;
      if (result && result.length) {
        this.advanceDataSource.data = result;
        this.showInvoiceSearchResults = false;
        this.showInvoiceAdvanceSearchResults= true;
      }
    });
  }
  /*event to open remarks/templates */
  showPopup(type) {
    if (type === 'remarks') {
      if (!this.invoiceSearchResults['ir'].length || !this.invoiceSearchResults['ir'][0].SEQ_NBR) {
        this.snackBar.open('Remarks does not exist for this Invoice', 'CLOSE', {
          duration: 3000,
          horizontalPosition: 'right',
          verticalPosition: 'top'
        });
        return;
      }
    }
    if (type === 'template') {
      if (!this.invoiceSearchResults['template'].length || !this.invoiceSearchResults['template'][0].SEQ_NBR) {
        this.snackBar.open('Templates does not exist for this Invoice', 'CLOSE', {
          duration: 3000,
          horizontalPosition: 'right',
          verticalPosition: 'top'
        });
        return;
      }
    }
    const popupTypes = {
      'remarks': InvDisplayRemarksComponent,
      'template': InvDisplayTemplateComponent
    };
    this.dialog.open(popupTypes[type], {
      disableClose: false,
      data: {
        resultSet: this.invoiceSearchResults
      }
    }, ).afterClosed().subscribe((result) => {
      this.result = result;
      if (result && result.data) {
        this.showInvoiceSearchResults = false;
      }
    });
  }

  showTaxDetail(index) {
    console.log(index);
  }

  searchFromInvoiceLink(scope, row) {
    scope.searchForm.patchValue({
      'inv_number': row.INVOICE_NBR,
      'so_number': '',
      'gst_number': ''
    });
    scope.searchInvoice.call(scope);
  }

  searchFromSOLink(scope, row) {
    console.log(row.LSS_INV_NBR)
    scope.searchForm.patchValue({
      'inv_number': '',
      'so_number': row.LSS_INV_NBR,
      'gst_number': ''
    });
    scope.searchInvoice.call(scope);
  }
  
  searchInvoice() {
    this.disableSearchBtn = true;
    this.is.getOi(this.searchForm.value).subscribe((data: any) => {
      this.disableSearchBtn = false;
      if (!!data.success) {
        const admin_cty = data.data.admin_cty[0].ADMIN_CTY_CD;
        if (admin_cty === 'IN' || data.data.ih[0].REM_CTY_CD === 'IN') {
          this.gstEnabled = true;
        }
        this.invoiceSearchResults = data.data;
        const imDataSet = this.prepareImDataSet(data.data.im, data.data.ig);
        this.dataSource.data = imDataSet;
        this.hdrInvAmt = this.getInvAmount();
        this.showInvoiceSearchResults = true;
        this.showInvoiceAdvanceSearchResults = false;
        this.showSearchForm = false;
        setTimeout(() => {
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }, 100);
      }
    }, (e) => {
      console.log(e);
      this.disableSearchBtn = false;
    });
  }
  prepareImDataSet(data, ig) {
    for (let i = 0; i < data.length; i++) {
      if (this.gstEnabled) {
        data[i].GSTR1TC = 'CGST';
        data[i].GSTR1TP = data[i].CGST_TAX_PCT;
        data[i].GSTR1TA = data[i].CGST_TAX_AMT;
        data[i].GSTR2TC = 'IGST';
        data[i].GSTR2TP = data[i].IGST_TAX_PCT;
        data[i].GSTR2TA = data[i].IGST_TAX_AMT;
        data[i].GSTR3TC = 'SGST';
        data[i].GSTR3TP = data[i].SGST_TAX_PCT;
        data[i].GSTR3TA = data[i].SGST_TAX_AMT;
        data[i].GSTR4TC = 'UGST';
        data[i].GSTR4TP = data[i].UGST_TAX_PCT;
        data[i].GSTR4TA = data[i].UGST_TAX_AMT;
      } else {
        data[i].GSTR1TC = data[i].INV_CHRG_TAX_CD;
        data[i].GSTR1TP = data[i].INV_CHRG_TAX_PCT;
        data[i].GSTR1TA = data[i].INV_CHRG_TAX_AMT;
        data[i].GSTR2TC = ' ';
        data[i].GSTR2TP = '0';
        data[i].GSTR2TA = '0';
        data[i].GSTR3TC = ' ';
        data[i].GSTR3TP = '0';
        data[i].GSTR3TA = '0';
        data[i].GSTR4TC = ' ';
        data[i].GSTR4TP = '0';
        data[i].GSTR4TA = '0';
      }
    }
    return data;
  }
  getInvAmount() {
    let amount = 0;
    let tax = 0;
    const ig = this.invoiceSearchResults['ig'];
    for (let i = 0; i < ig.length; i++) {
      amount += parseFloat(ig[i].AMOUNT_2);
      tax += parseFloat(ig[i].INV_CHRG_TAX_AMT);
    }
    return {
      amount: amount,
      tax: tax,
      total: amount + tax,
      currency: ig[0].CURRENCY_CD
    };
  }
  onFilterChange(value) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }
  onAdvanceFilterChange(value) {
    if (!this.advanceDataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.advanceDataSource.filter = value;
  }
}
