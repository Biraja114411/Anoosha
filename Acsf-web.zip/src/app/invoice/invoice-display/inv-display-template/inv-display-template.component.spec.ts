import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvDisplayTemplateComponent } from './inv-display-template.component';

describe('InvDisplayTemplateComponent', () => {
  let component: InvDisplayTemplateComponent;
  let fixture: ComponentFixture<InvDisplayTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvDisplayTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvDisplayTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
