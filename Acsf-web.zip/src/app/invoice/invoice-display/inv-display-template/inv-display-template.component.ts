import {Component, Inject, Input, OnDestroy, OnInit, ViewChild} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ListColumn } from '../../../../@acsf/shared/list/list-column.model';
import {fadeInRightAnimation} from '../../../../@acsf/animations/fade-in-right.animation';
import {fadeInUpAnimation, fadeInUpStaggerAnimation} from '../../../../@acsf/animations/fade-in-up.animation';

@Component({
  selector: 'acsf-inv-display-template',
  templateUrl: './inv-display-template.component.html',
  styleUrls: ['./inv-display-template.component.scss'],
  animations: [fadeInRightAnimation, fadeInUpAnimation, fadeInUpStaggerAnimation]
})
export class InvDisplayTemplateComponent implements OnInit {

  private _gap = 16;
  gap = `${this._gap}px`;
  col1 = `1 calc(80% - ${this._gap / 2}px)`;
  col2 = `1 1 calc(50% - ${this._gap / 1.5}px)`;
  col3 = `1 1 calc(33.3333% - ${this._gap / 1.5}px)`;
  col4 = `1 1 calc(23% - ${this._gap / 1.5}px)`;
  col5 = `1 1 calc(120px - ${this._gap / 1.5}px)`;

  @Input()
  columns: ListColumn[] = [
    {name: 'Sequence', property: 'SEQ_NBR', visible: true, isModelProperty: true},
    {name: 'ACS VOY', property: 'ACS_VOY', visible: true, isModelProperty: true},
    {name: 'CLP#', property: 'CLP_NBR', visible: true, isModelProperty: true},
    {name: 'BOOKING', property: 'BOOKING', visible: true, isModelProperty: true},
    {name: 'PO#', property: 'PO_NBR', visible: false, isModelProperty: true},
    {name: 'STYLE', property: 'STYLE', visible: false, isModelProperty: true},
    {name: 'SUB_STYLE', property: 'SUB_STYLE', visible: false, isModelProperty: true},
    {name: 'BL#', property: 'BL_NBR', visible: true, isModelProperty: true},
    {name: 'CARRIER', property: 'CARRIER_CD', visible: true, isModelProperty: true},
    {name: 'HBL BL#', property: 'HBL_BL_NBR', visible: false, isModelProperty: true},
    {name: 'ADOD', property: 'ADOD', visible: false, isModelProperty: true},
    {name: 'AMOUNT', property: 'AMOUNT', visible: false, isModelProperty: true},
    {name: 'ASAP', property: 'ASAP', visible: false, isModelProperty: true},
    {name: 'RMK', property: 'RMK', visible: false, isModelProperty: true},
    {name: 'INCOTERMS', property: 'INCOTERMS', visible: false, isModelProperty: true},
    {name: 'BRAND', property: 'BRAND', visible: false, isModelProperty: true},
    {name: 'CARTON', property: 'CARTON', visible: false, isModelProperty: true},
    {name: 'COLLECT', property: 'COLLECT', visible: false, isModelProperty: true},
    {name: 'CONSIGNEE', property: 'CONSIGNEE', visible: false, isModelProperty: true},
    {name: 'CNTR#', property: 'CNTR_NBR', visible: true, isModelProperty: true},
    {name: 'CTR SIZE', property: 'CTR_SIZE', visible: false, isModelProperty: true},
    {name: 'COST USD', property: 'COST_USD', visible: false, isModelProperty: true},
    {name: 'CPO', property: 'CPO', visible: false, isModelProperty: true},
    {name: 'CUSTOMER', property: 'CUSTOMER_CODE', visible: false, isModelProperty: true},
    {name: 'DIVISION', property: 'DIVISION_NBR', visible: false, isModelProperty: true},
    {name: 'FINAL DEST', property: 'FINAL_DEST', visible: false, isModelProperty: true},
    {name: 'GL CONSOLIDATION', property: 'GL_CONSOLIDATION', visible: false, isModelProperty: true},
    {name: 'GL DEST DRAYAGE', property: 'GL_DEST_DRAYAGE', visible: false, isModelProperty: true},
    {name: 'GL OCF ACC', property: 'GL_OCF_AND_ACC', visible: false, isModelProperty: true},
    {name: 'HBL#', property: 'HBL_NBR', visible: false, isModelProperty: true},
    {name: 'Int. PO', property: 'INT_PO', visible: false, isModelProperty: true},
    {name: 'LIN', property: 'LIN', visible: false, isModelProperty: true},
    {name: 'MGFEE', property: 'MGFEE', visible: false, isModelProperty: true},
    {name: 'PKGS', property: 'PKGS', visible: false, isModelProperty: true},
    {name: 'UOM', property: 'UOM', visible: false, isModelProperty: true},
    {name: 'PLANT_CODE', property: 'PLANT_CODE', visible: false, isModelProperty: true},
    {name: 'REF#', property: 'REF_NBR', visible: true, isModelProperty: true},
    {name: 'SHIP TO', property: 'SHIP_TO', visible: false, isModelProperty: true},
    {name: 'SHIPMENT BL#', property: 'SHIPMENT_BL_NBR', visible: false, isModelProperty: true},
    {name: 'SHIPMENT#', property: 'SHIPMENT_NBR', visible: false, isModelProperty: true},
    {name: 'SHIPPER NAME', property: 'SHIPPER_NAME', visible: false, isModelProperty: true},
    {name: 'SWY PO#', property: 'SWY_PO_NO', visible: false, isModelProperty: true},
    {name: 'CBM', property: 'CBM', visible: false, isModelProperty: true},
    {name: 'ROUTE', property: 'ROUTE', visible: false, isModelProperty: true},
    {name: 'KGS', property: 'KGS', visible: false, isModelProperty: true},
    {name: 'WHC', property: 'WHC', visible: false, isModelProperty: true},
    {name: 'LI BL#', property: 'LI_BL', visible: false, isModelProperty: true},
    {name: 'LI SO#', property: 'LI_SO', visible: false, isModelProperty: true},
    {name: 'LI EXCHANGE RATE', property: 'LI_EXCHANGE_RATE', visible: false, isModelProperty: true},
    {name: 'LI CNTR#', property: 'LI_CNTR_NBR', visible: false, isModelProperty: true},
    {name: 'LI HBL#', property: 'LI_HBL_NBR', visible: false, isModelProperty: true},
    {name: 'LI FCR#', property: 'LI_FCR_NBR', visible: false, isModelProperty: true},
    {name: 'CREATE USER', property: 'CREATE_USER_ID_CD', visible: false, isModelProperty: true},
    {name: 'CREATE TSTAMP', property: 'CREATE_TSTAMP', visible: false, isModelProperty: true},
    {name: 'Last Update User', property: 'LST_UPD_USER_ID_CD', visible: false, isModelProperty: true},
    {name: 'Last Update TSTAMP', property: 'LST_UPD_TSTAMP', visible: false, isModelProperty: true}
  ] as ListColumn[];
  pageSize = 5;
  dataSource: MatTableDataSource<any> | null;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  constructor(private dialogRef: MatDialogRef<any>, @Inject(MAT_DIALOG_DATA) public invoiceData: any) { }

  ngOnInit() {
    this.dataSource = new MatTableDataSource();
    this.dataSource.data = this.invoiceData.resultSet.template;
    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, 1000);
  }

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  onFilterChange(value) {
    if (!this.dataSource) {
      return;
    }
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

}
