export class InvoiceDataModel {
  LN: number;
  CODE: string;
  DESC: string;
  SVC: string;
  CCY: string;
  UNIT: string;
  QTY: number;
  RATE: number;
  AMOUNT: number;
  EXCH_RATE: number;
  CGST: number;
  CGST_AM: number;
  IGST: number;
  IGST_AMT: number;
  SGST: number;
  SGST_AMT: number;
  UGST: number;
  UGST_AMT: number;
  PAY_AMOUNT: number;
  M: string;
  REFERENCE: string;
  VAT: string;
  RSN: string;

  constructor(iData) {
    this.LN = iData.SEQ_NBR;
    this.CODE = iData.CHARGE_CD;
    this.DESC = iData.CHARGE_DESC;
    this.SVC = iData.SERVICE_TYPE_CD;
    this.CCY = iData.CURRENCY_CD;
    this.UNIT = iData.UNIT_CD_1;
    this.QTY = iData.QUANTITY_1;
    this.RATE = iData.RATE;
    this.AMOUNT = iData.AMOUNT_1;
    this.EXCH_RATE = iData.EXCHANGE_RATE;
    this.CGST = iData.CGST_TAX_PCT;
    this.CGST_AM = iData.CGST_TAX_AMT;
    this.IGST = iData.IGST_TAX_PCT;
    this.IGST_AMT = iData.IGST_TAX_AMT;
    this.SGST = iData.SGST_TAX_PCT;
    this.SGST_AMT = iData.SGST_TAX_AMT;
    this.UGST = iData.UGST_TAX_PCT;
    this.UGST_AMT = iData.UTGST_TAX_AMT;
    this.PAY_AMOUNT = parseFloat(iData.AMOUNT_2) + parseFloat(iData.INV_CHRG_TAX_AMT);
    this.M = iData.MAN_CHRG_FLG;
    this.REFERENCE = iData.INVC_CHRG_REF_NBR;
    this.VAT = iData.VAT_ID_NBR;
    this.RSN = iData.CHG_REASON_CD;
  }

}
