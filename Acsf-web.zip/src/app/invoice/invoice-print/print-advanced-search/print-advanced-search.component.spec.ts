import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintAdvancedSearchComponent } from './print-advanced-search.component';

describe('PrintAdvancedSearchComponent', () => {
  let component: PrintAdvancedSearchComponent;
  let fixture: ComponentFixture<PrintAdvancedSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrintAdvancedSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintAdvancedSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
