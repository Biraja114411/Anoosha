import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';

@Injectable({
    providedIn: 'root'
})

export class InvoicePrintService {
    constructor(private http: HttpClient) {
    }

    getUserProfile() {
        const url = 'http://127.0.0.1:3333/api/v1/user';
        return this.http.get(url, { withCredentials: true, params: {data: ''} });
    }

    validateInvoice(data) {
        const url = 'http://127.0.0.1:3333/api/v1/invoice/validate/oi';
        return this.http.get(url, { withCredentials: true, params: {data: data} });
    }
    confirmPrint(data) {
        const url = 'http://127.0.0.1:3333/api/v1/invoice/print/oi';
        return this.http.get(url, {
            params: {
                data: JSON.stringify(data)
            }
        });
    }

}
