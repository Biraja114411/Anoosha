import {Component, Inject, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {fadeInUpStaggerAnimation} from '../../../@acsf/animations/fade-in-up.animation';
import {fadeInRightAnimation} from '../../../@acsf/animations/fade-in-right.animation';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {PrintAdvancedSearchComponent} from './print-advanced-search/print-advanced-search.component';
import { InvoicePrintService } from './invoice-print.service';

@Component({
    selector: 'acsf-invoice-print',
    templateUrl: './invoice-print.component.html',
    styleUrls: ['./invoice-print.component.scss'],
    animations: [fadeInUpStaggerAnimation, fadeInRightAnimation]
})
export class InvoicePrintComponent implements OnInit {
    printSearchFormGroup: FormGroup;
    printOptionFormGroup: FormGroup;
    errorMsg = '';
    invoiceValidationError = '';
    userProfile: {};

    private _gap = 16;
    gap = `${this._gap}px`;
    col1 = `1 calc(80% - ${this._gap / 2}px)`;
    col2 = `1 calc(70% - ${this._gap / 2}px)`;
    col3 = `1 1 calc(33.3333% - ${this._gap / 1.5}px)`;
    col5 = `1 1 calc(15.3333% - ${this._gap / 1.5}px)`;
    commentLength = 67;

    placeholder: [String, 'Invoice'];

    constructor(private dialog: MatDialog, private fb: FormBuilder, private ip: InvoicePrintService) {
    }

    ngOnInit() {
        this.printSearchFormGroup = this.fb.group({
            selection_type: 'single',
            invoice_list: [],
            r1_lower_limit: '',
            r1_upper_limit: '',
            r2_lower_limit: '',
            r2_upper_limit: '',
            draft: false,
            final: false,
            reprint: false,
            format: 'D',
            shipment_ref: true,
            comments: '',
        });
        this.printOptionFormGroup = this.fb.group({});

        this.ip.getUserProfile().subscribe((response: any) => {
            this.userProfile = response.user[0];
        }, (e) => {
            console.log('Error ', e);
        });
    }

    openAdvancedPrintDialog() {
        this.dialog.open(PrintAdvancedSearchComponent, {
            disableClose: false
        }).afterClosed().subscribe(result => {
            console.log(result);
        });
    }

    openPrintOptionDialog() {
        const formData = this.printSearchFormGroup.value;
        this.invoiceValidationError = '';
        if (!formData.invoice_list) {
            this.invoiceValidationError = 'At least one invoice number is required';
            return;
        }
        const invoiceList = formData.invoice_list.map((e) => {
            return e.value;
        });

        this.ip.validateInvoice(invoiceList).subscribe((res: any) => {
            console.log(res.data);
            if (res.data.length !== invoiceList.length) {
                this.invoiceValidationError = this.getInvoiceString({original: invoiceList, validated: res.data});
                return;
            } else {
                const invoiceStatusError = this.checkInvoiceStatus(res.data);
                console.log(this.printSearchFormGroup.value);
                if (!invoiceStatusError) {
                    return;
                }
                this.dialog.open(PrintOptionComponent, {
                    disableClose: false,
                    data: {
                        formData: this.printOptionFormGroup.value
                    }
                }).afterClosed().subscribe(result => {
                    const printData = {
                        data: this.printSearchFormGroup.value,
                        config: result,
                        user: this.userProfile
                    };
                    console.log('Print data, ', printData)
                    this.ip.confirmPrint(printData).subscribe((data: any) => {
                        console.log(data);
                    }, (e) => {
                        console.log('Error ', e);
                    });
                });
            }
        }, (e) => {
            console.log('Error: ', e);
        });
    }
    checkInvoiceStatus(invoiceList) {
        const formData = this.printSearchFormGroup.value;
        invoiceList.forEach((v, i) => {
            const inv_status = v.INVOICE_STATUS_CD.trim();
            if (!formData.final && (inv_status !== 'P' || inv_status !== 'V')) {
                this.printSearchFormGroup.patchValue(
                    {
                        draft: true
                    }
                );
            } else if (!formData.final && (inv_status === 'P' || inv_status === 'V')) {
                this.printSearchFormGroup.patchValue(
                    {
                        final: true,
                        draft: false,
                        reprint: true
                    }
                );
            } else if (formData.final && inv_status !== 'A') {
                this.invoiceValidationError = `${v.INVOICE_NBR} cannot be final printed. Check invoice status.`;
                return false;
            } else {}
        });
        return true;
    }

    getInvoiceString(data) {
        const invalidInvoiceList = [];
        const validatedList = data.validated.map((e) => {
            return e.INVOICE_NBR;
        });
        data.original.forEach((v, i) => {
           if (validatedList.indexOf(v) === -1) {
               invalidInvoiceList.push(v);
           }
        });

        return `Invoice# ${invalidInvoiceList.join(', ')} ${invalidInvoiceList.length > 1 ? 'are' : 'is'} not valid`;
    }

    onSubmit() {
        console.log(this.printSearchFormGroup.value);
    }

}

@Component({
    selector: 'acsf-print-option-dialog',
    template: `
        <div mat-dialog-title fxLayout="row" fxLayoutAlign="space-between center">
            <div>Print configuration</div>
            <button type="button" mat-icon-button (click)="close('No answer')" tabindex="-1">
                <mat-icon>close</mat-icon>
            </button>
        </div>
        <mat-dialog-content>
            <form [formGroup]="printOptionFormGroup" (ngSubmit)="confirmPrint()">
                <div fxLayout="column" fxLayout.gt-sm="row" fxLayoutGap="8px" fxLayoutGap.gt-sm="16px" class="mb-16  mt-15">
                    <acsf-card-header-heading>Choose print type</acsf-card-header-heading>
                    <br>
                    <mat-radio-group formControlName="print_type">
                        <mat-radio-button class="radio" value="E" style="margin-right:30px"> Email</mat-radio-button>
                        <mat-radio-button class="radio" value="H" style="margin-right:30px"> Print</mat-radio-button>
                    </mat-radio-group>
                </div>
                <div class="mb-16">
                    <div *ngIf="printOptionFormGroup.get('print_type').value=='E'" fxLayout="column" fxLayout.gt-sm="row" fxLayoutGap="8px" fxLayoutGap.gt-sm="16px">
                        <mat-form-field appearance="standard" class="acsf-flex-form-field" color="accent" fxFlex.gt-sm>
                            <mat-label>Enter Email</mat-label>
                            <input type="email" matInput formControlName="print_email">
                            <mat-hint *ngIf="f.print_email.dirty && f.print_email.errors" align="start" class="warn-text">Provide a valid email address</mat-hint>
                        </mat-form-field>
                    </div>
                    <div *ngIf="printOptionFormGroup.get('print_type').value=='H'" fxLayout="column" fxLayout.gt-sm="row" fxLayoutGap="8px" fxLayoutGap.gt-sm="16px">
                        <mat-form-field appearance="standard" class="acsf-flex-form-field" color="accent" fxFlex.gt-sm>
                            <mat-label>Print At City</mat-label>
                            <input matInput required formControlName="print_city" maxlength="3">
                            <mat-hint *ngIf="f.print_city.dirty && f.print_city.errors" align="start" class="warn-text">Invalid city code</mat-hint>
                        </mat-form-field>
                        <mat-form-field appearance="standard" class="acsf-flex-form-field" color="accent" fxFlex.gt-sm>
                            <mat-label>Printer ID</mat-label>
                            <input matInput required formControlName="print_id" maxlength="3">
                            <mat-hint *ngIf="f.print_id.dirty && f.print_id.errors" align="start" class="warn-text">Invalid printer ID</mat-hint>
                        </mat-form-field>
                    </div>
                    <div fxLayout="column" fxLayout.gt-sm="row" fxLayoutGap="8px" fxLayoutGap.gt-sm="16px">
                        <mat-form-field appearance="standard" class="acsf-flex-form-field" color="accent" fxFlex.gt-sm>
                            <mat-label>Form NBR</mat-label>
                            <input matInput required formControlName="print_nbr">
                            <mat-hint *ngIf="f.print_nbr.dirty && f.print_nbr.errors" align="start" class="warn-text">
                                Invalid form number
                            </mat-hint>
                        </mat-form-field>
                        <mat-form-field appearance="standard" class="acsf-flex-form-field" color="accent" fxFlex.gt-sm>
                            <mat-label>No of Sets</mat-label>
                            <input matInput required formControlName="print_sets" maxlength="1">
                            <mat-hint *ngIf="f.print_sets.dirty && f.print_sets.errors" align="start" class="warn-text">
                                Invalid number of sets
                            </mat-hint>
                        </mat-form-field>
                    </div>
                    <div fxLayout="column" fxLayout.gt-sm="row" fxLayoutGap="8px" fxLayoutGap.gt-sm="16px">
                        <mat-form-field appearance="standard" class="acsf-flex-form-field" color="accent" fxFlex.gt-sm>
                            <mat-label>Print priority</mat-label>
                            <mat-select formControlName="print_priority">
                                <mat-option value="1">Single</mat-option>
                                <mat-option value="2">Duplex</mat-option>
                            </mat-select>
                        </mat-form-field>
                    </div>
                    <div fxLayout="column" fxLayout.gt-sm="row" fxLayoutGap="8px" fxLayoutGap.gt-sm="16px">
                        <button mat-raised-button type="submit" color="primary" class="acsf-search-btn">Print</button>
                    </div>
                </div>
            </form>
        </mat-dialog-content>      `
})

export class PrintOptionComponent {
    printOptionFormGroup: FormGroup;
    errorMsg = '';

    constructor(private dialogRef: MatDialogRef<PrintOptionComponent>, @Inject(MAT_DIALOG_DATA) public searchData: any, private fb: FormBuilder) {
        console.log(this.searchData);
    }

    // tslint:disable-next-line:use-life-cycle-interface
    ngOnInit() {
        this.printOptionFormGroup = this.fb.group({
            print_type: 'E',
            print_email: ['', [Validators.email]],
            print_city: ['PNX', [Validators.minLength(3), Validators.max(3)]],
            print_id: ['099', [Validators.minLength(3), Validators.maxLength(3)]],
            print_nbr: ['P01X', [Validators.required, Validators.minLength(4), Validators.max(4)]],
            print_sets: [1, [Validators.required, Validators.min(1), Validators.max(9)]],
            print_report_frequency: ['OIMM', [Validators.required, Validators.minLength(4), Validators.max(4)]],
            print_priority: ['2', Validators.required]
        });
    }

    get f() { return this.printOptionFormGroup.controls; }

    close(data) {
        this.dialogRef.close(data);
    }

    confirmPrint() {
        if (this.printOptionFormGroup.invalid) {
            return;
        }
        this.dialogRef.close(this.printOptionFormGroup.value);
    }
}

