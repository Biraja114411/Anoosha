import { Directive } from '@angular/core';

@Directive({
  selector: '[acsfPage],acsf-page',
  host: {
    class: 'acsf-page'
  }
})
export class PageDirective {

  constructor() { }

}
