import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {
  AcsfCard,
  AcsfCardActions,
  AcsfCardContent,
  AcsfCardHeader,
  AcsfCardHeaderActions,
  AcsfCardHeaderSubTitle,
  AcsfCardHeaderTitle
} from './card.component';

const cardComponents = [
  AcsfCard,
  AcsfCardHeader,
  AcsfCardHeaderTitle,
  AcsfCardHeaderSubTitle,
  AcsfCardHeaderActions,
  AcsfCardContent,
  AcsfCardActions
];

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ...cardComponents
  ],
  exports: [
    ...cardComponents
  ]
})
export class AcsfCardModule {
}
