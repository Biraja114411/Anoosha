import { ChangeDetectionStrategy, Component, Directive, Input, ViewEncapsulation } from '@angular/core';

// noinspection TsLint
@Component({
  selector: 'acsf-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss'],
  host: { 'class': 'acsf-card' },
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AcsfCard {
}

// noinspection TsLint
@Component({
  selector: 'acsf-card-header',
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { 'class': 'acsf-card-header' },
  template: `
    <div class="acsf-card-header-heading-group">
      <ng-content select="acsf-card-header-heading"></ng-content>
      <ng-content select="acsf-card-header-subheading"></ng-content>
    </div>
    <ng-content></ng-content>
    <ng-content select="acsf-card-header-actions"></ng-content>
  `
})
export class AcsfCardHeader {
}

// noinspection TsLint
@Component({
  selector: 'acsf-card-content',
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { 'class': 'acsf-card-content' },
  template: `
    <ng-content></ng-content>`
})
export class AcsfCardContent {
}

// noinspection TsLint
@Directive({
  selector: 'acsf-card-header-heading',
  host: { 'class': 'acsf-card-header-heading' }
})
export class AcsfCardHeaderTitle {
}

// noinspection TsLint
@Directive({
  selector: 'acsf-card-header-subheading',
  host: { 'class': 'acsf-card-header-subheading' }
})
export class AcsfCardHeaderSubTitle {
}

// noinspection TsLint
@Directive({
  selector: 'acsf-card-header-actions',
  host: { 'class': 'acsf-card-header-actions' }
})
export class AcsfCardHeaderActions {
}

// noinspection TsLint
@Directive({
  selector: 'acsf-card-actions',
  host: {
    'class': 'acsf-card-actions',
    '[class.acsf-card-actions-align-end]': 'align === "end"',
  }
})
export class AcsfCardActions {
  /** Position of the actions inside the card. */
  @Input() align: 'start' | 'end' = 'start';
}
