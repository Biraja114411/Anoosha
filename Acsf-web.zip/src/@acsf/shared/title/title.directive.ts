import { Directive } from '@angular/core';

@Directive({
  selector: '[acsfTitle],acsf-title',
  host: {
    class: 'acsf-title'
  }
})
export class TitleDirective {

  constructor() { }

}
