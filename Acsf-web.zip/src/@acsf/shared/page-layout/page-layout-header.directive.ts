import { Directive } from '@angular/core';

@Directive({
  selector: '[acsfPageLayoutHeader],acsf-page-layout-header',
  host: {
    class: 'acsf-page-layout-header'
  }
})
export class PageLayoutHeaderDirective {

  constructor() { }

}

