import { Directive, HostBinding, Input } from '@angular/core';

@Directive({
  selector: '[acsfPageLayout],acsf-page-layout',
  host: {
    class: 'acsf-page-layout'
  }
})
export class PageLayoutDirective {

  @Input() mode: 'card' | 'simple' = 'simple';

  constructor() { }

  @HostBinding('class.acsf-page-layout-card')
  get isCard() {
    return this.mode === 'card';
  }

  @HostBinding('class.acsf-page-layout-simple')
  get isSimple() {
    return this.mode === 'simple';
  }

}
