export class ChartWidgetOptions {
  title: string;
  gain?: number | string;
  subTitle?: string;
  background?: string;
  color?: string;
}
